# ECLIPSEOS v9.1 Offline Brain API

The interface works without the Python service. When the service is absent, LYS automatically uses the safe local fallback and displays **OFFLINE BRAIN**.

## Start locally

```bash
python -m pip install fastapi uvicorn
uvicorn brain.server:app --host 127.0.0.1 --port 8000
```

If Python cannot resolve sibling modules from the project root, run `uvicorn server:app` inside the `brain` directory.

## Endpoints

- `GET /health` — service status.
- `GET /lys?q=22%20%2B%205&mode=tierna` — LYS response. Modes: `tierna`, `capitana`.
- `GET /kkamak?sector=Gangnam` — KKAMAK scan report.

Math uses a restricted Python syntax tree. It never executes arbitrary code. Browser input is length-limited and encoded before transport.

## GitHub Pages

GitHub Pages hosts the static interface only. The optional brain runs on the visitor's own `localhost:8000`; no API key or remote service is required.