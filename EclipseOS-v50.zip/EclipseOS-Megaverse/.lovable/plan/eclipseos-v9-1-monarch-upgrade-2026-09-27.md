# EclipseOS v9.1 Monarch Upgrade

## Build
- Replace the placeholder home screen with a mobile-first Shadow OS interface preserving all required DOM IDs and existing lore.
- Create the hero particle field, RGB scanline, ARISE glitch/audio response, mouse-reactive LYS and KKAMAK sprites, theme selector, and six-language controls.
- Add Nexus search, telemetry, missions, ARCHK Forge with animated emoji-code canvas, Gates, Shadow Army tilt cards, lore timeline, locked Criminales Sombra teaser, command terminal, and virtualized 847-row Wiki.

## Runtime behavior
- Split browser logic into focused ES modules for safe storage, ARCHK parsing, 500-unit search, virtual Wiki rendering, localization, character behavior, terminal commands, and the optional local Python brain.
- Keep browser features operational when media files or the localhost brain are unavailable, with visible offline status and local LYS fallback.
- Parse user input as data only; do not evaluate code or inject user strings as HTML.

## Offline brain and documentation
- Add a FastAPI localhost service with LYS tierna/capitana modes, safe arithmetic, and KKAMAK scan responses.
- Document setup and endpoints in `docs/BRAIN_API.md`, including the separation between the static GitHub Pages interface and optional local brain.

## Project integration
- Implement the requested experience inside the existing TanStack project while also providing the requested static-style folders and modules under `public/` for GitHub Pages-compatible assets.
- Add unique page metadata and record the project structure decision in `AGENTS.md`.

## Verification
- Check the generated page on desktop and mobile, exercise ARISE, compile preview, search, Wiki scrolling, themes, terminal commands, and offline LYS fallback.
- Confirm the preview build has no errors and the required IDs remain present.
