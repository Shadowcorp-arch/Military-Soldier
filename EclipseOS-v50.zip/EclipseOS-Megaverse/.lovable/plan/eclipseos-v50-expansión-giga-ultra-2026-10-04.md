# ECLIPSEOS v50 — expansión GIGA-ULTRA

## Objetivo
Convertir ECLIPSEOS en una plataforma dinámica de juegos y creación inspirada en los parámetros ARCHK v50: 25 juegos totales, perfil visual completo, clima vivo, RGB avanzado y un panel principal mucho más útil.

## Experiencia que se construirá

### 1. Shadow Arcade: 25 juegos
- Integrar **SWAT Extraction** como juego principal con infiltración, visión enemiga, armas, niveles de dificultad, archivos de inteligencia, extracción y bonificación fantasma.
- Mantener los cuatro juegos actuales y añadir 20 experiencias nuevas agrupadas por Acción, Estrategia, Arcade, Puzzle y Simulación.
- Cada juego tendrá instrucciones, dificultad, puntuación, récord y recompensas de XP.
- Crear un catálogo visual con búsqueda, filtros, favoritos y estado “nuevo”. Los juegos ligeros compartirán motores sólidos para mantener buen rendimiento.

### 2. Dashboard y perfil del cazador
- Rediseñar el panel principal con resumen de nivel, XP, ECLIP, racha diaria, récords de los 25 juegos, calendario, actividad reciente y desafíos.
- Añadir editor de avatar con emojis, colores, marcos desbloqueables y carga de imagen desde móvil o PC.
- Guardar nombre, biografía, avatar y preferencias por cuenta.
- Añadir recompensa diaria y acceso visual a ofertas diarias ECLIP ya preparadas.

### 3. Acceso y creación de cuenta
- Mejorar la pantalla de acceso con animaciones, estados claros y los logotipos multicolor correctos de Google y Microsoft, además de Apple.
- Conservar email/contraseña, creación de cuenta, confirmación por correo y recuperación de contraseña.
- Mostrar GitHub, Discord y Xbox como integraciones futuras sin simular acceso: no son proveedores disponibles en Lovable Cloud.
- Mantener Google, Apple y Microsoft como accesos reales y configurados.

### 4. RGB Lab v50 y movimiento
- Ampliar modos a Off, Static, Rainbow, Pulse, Wave, Fire, Ice y Diamond.
- Añadir color primario/secundario, velocidad, brillo, intensidad, líneas de borde, resplandor, partículas y sincronización de interfaz.
- Aplicar animaciones cuidadas a tarjetas, cambios de página, estadísticas, clima y controles; respetar la opción de reducir movimiento.

### 5. Clima y ARCHK v50
- Crear un módulo de clima de Seoul Nexus con estados dinámicos offline: lluvia, tormenta, niebla, nieve, eclipse y aurora.
- Convertir una selección de los parámetros aportados en comandos reales del compilador: terreno, ciudad, criaturas, elementos, clima, efectos RGB y tokens emoji.
- Ampliar el Codex/Wiki con categorías y explicaciones profesionales de comandos, juegos y herramientas, manteniendo virtualización para alto rendimiento.
- No ejecutar texto del usuario: ARCHK seguirá interpretándose como datos seguros.

### 6. Navegación y acabados
- Conectar las páginas y menús que falten sin enlaces rotos.
- Mejorar adaptación móvil, controles táctiles, sonidos y respuesta visual.
- Mantener intactos `#archk-code`, `#compileButton`, `#megaItems`, `#wikiBody`, `#lysChat`, `#btnArise` y el comportamiento existente.

## Datos y seguridad
- Crear un espacio privado de imágenes de avatar; cada usuario solo podrá gestionar la suya.
- Mantener roles en la tabla segura existente y el administrador total para `shadowcorpcompany@gmail.com`.
- Las puntuaciones, XP, ECLIP, recompensas y compras seguirán validadas por el sistema, no por el navegador.

## Validación
- Probar creación e inicio de sesión, carga y edición de avatar, recompensa diaria, panel RGB, SWAT y una muestra de cada familia de juegos.
- Revisar escritorio y móvil, errores visibles, navegación, sonido, rendimiento y compilación final.
