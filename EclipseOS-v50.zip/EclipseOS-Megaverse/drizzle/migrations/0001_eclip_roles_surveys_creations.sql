-- ECLIP wallet + avatar
ALTER TABLE public.profiles
  ADD COLUMN eclip int NOT NULL DEFAULT 100,
  ADD COLUMN last_daily date,
  ADD COLUMN streak int NOT NULL DEFAULT 0,
  ADD COLUMN avatar_emoji text NOT NULL DEFAULT '👤',
  ADD COLUMN avatar_color text NOT NULL DEFAULT '190',
  ADD COLUMN avatar_frame text NOT NULL DEFAULT 'none',
  ADD COLUMN bio text NOT NULL DEFAULT '',
  ADD COLUMN owned_items text[] NOT NULL DEFAULT '{}';
-- Users may not edit wallet columns directly
REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE (hunter_name, avatar_url, theme, rgb_mode, xp, level, updated_at, avatar_emoji, avatar_color, avatar_frame, bio) ON public.profiles TO authenticated;

-- Roles
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
CREATE POLICY "own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins read profiles" ON public.profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins read scores" ON public.game_scores FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Creator account = admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, hunter_name, avatar_url)
  VALUES (NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'hunter_name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1), 'Hunter'),
    NEW.raw_user_meta_data->>'avatar_url')
  ON CONFLICT (id) DO NOTHING;
  IF lower(NEW.email) = 'shadowcorpcompany@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin' FROM auth.users WHERE lower(email) = 'shadowcorpcompany@gmail.com' ON CONFLICT DO NOTHING;

-- Daily reward: 50 + 10 per streak day (max 150)
CREATE OR REPLACE FUNCTION public.claim_daily()
RETURNS json LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE p public.profiles; s int; gain int;
BEGIN
  SELECT * INTO p FROM public.profiles WHERE id = auth.uid() FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'no profile'; END IF;
  IF p.last_daily = current_date THEN RETURN json_build_object('ok', false, 'eclip', p.eclip, 'streak', p.streak); END IF;
  s := CASE WHEN p.last_daily = current_date - 1 THEN p.streak + 1 ELSE 1 END;
  gain := LEAST(150, 40 + s * 10);
  UPDATE public.profiles SET eclip = eclip + gain, last_daily = current_date, streak = s WHERE id = p.id;
  RETURN json_build_object('ok', true, 'gain', gain, 'eclip', p.eclip + gain, 'streak', s);
END; $$;

-- Shop purchase (prices server-side)
CREATE OR REPLACE FUNCTION public.buy_item(_item text)
RETURNS json LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE p public.profiles; price int;
BEGIN
  price := CASE _item
    WHEN 'frame-neon' THEN 120 WHEN 'frame-crimson' THEN 150 WHEN 'frame-gold' THEN 300
    WHEN 'frame-rainbow' THEN 450 WHEN 'emoji-pack' THEN 200 WHEN 'title-monarch' THEN 800
    ELSE NULL END;
  IF price IS NULL THEN RAISE EXCEPTION 'unknown item'; END IF;
  -- daily deal: 30% off the item of the day
  IF _item = (ARRAY['frame-neon','frame-crimson','frame-gold','frame-rainbow','emoji-pack','title-monarch'])[1 + (extract(doy FROM current_date)::int % 6)] THEN
    price := (price * 7) / 10;
  END IF;
  SELECT * INTO p FROM public.profiles WHERE id = auth.uid() FOR UPDATE;
  IF _item = ANY(p.owned_items) THEN RETURN json_build_object('ok', false, 'reason', 'owned'); END IF;
  IF p.eclip < price THEN RETURN json_build_object('ok', false, 'reason', 'funds'); END IF;
  UPDATE public.profiles SET eclip = eclip - price, owned_items = array_append(owned_items, _item) WHERE id = p.id;
  RETURN json_build_object('ok', true, 'eclip', p.eclip - price);
END; $$;
REVOKE EXECUTE ON FUNCTION public.claim_daily() FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.buy_item(text) FROM anon, public;
GRANT EXECUTE ON FUNCTION public.claim_daily() TO authenticated;
GRANT EXECUTE ON FUNCTION public.buy_item(text) TO authenticated;

-- Surveys
CREATE TABLE public.surveys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  options text[] NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.surveys TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.surveys TO authenticated;
GRANT ALL ON public.surveys TO service_role;
ALTER TABLE public.surveys ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone reads surveys" ON public.surveys FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins manage surveys" ON public.surveys FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.survey_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id uuid NOT NULL REFERENCES public.surveys(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  option_idx int NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (survey_id, user_id)
);
GRANT SELECT, INSERT ON public.survey_votes TO authenticated;
GRANT ALL ON public.survey_votes TO service_role;
ALTER TABLE public.survey_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "signed in read votes" ON public.survey_votes FOR SELECT TO authenticated USING (true);
CREATE POLICY "vote once as self" ON public.survey_votes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

INSERT INTO public.surveys (question, options) VALUES
('🎮 Which game should get a new season first?', ARRAY['🔫 SWAT Extraction','🐦‍⬛ KKAMAK Flight','🚪 Gate Runner','🔮 Rune Memory']),
('🌑 Criminales Sombra season: what do you want most?', ARRAY['New story chapters','New shadow soldiers','PvP gates','Boss raids']),
('🛠️ What will you create in the Studio?', ARRAY['🌐 Websites','📖 Stories','🎮 Games','📱 Apps']);

-- Announcements (creator broadcasts)
CREATE TABLE public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.announcements TO anon, authenticated;
GRANT INSERT, DELETE ON public.announcements TO authenticated;
GRANT ALL ON public.announcements TO service_role;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone reads announcements" ON public.announcements FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admins post announcements" ON public.announcements FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admins delete announcements" ON public.announcements FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
INSERT INTO public.announcements (message) VALUES ('👑 ECLIPSEOS v10 is live: SWAT Extraction, Creator Studio, LYS AI and daily ECLIP rewards!');

-- Creations (websites, stories, games, apps)
CREATE TABLE public.creations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL CHECK (kind IN ('website','story','game','app')),
  title text NOT NULL CHECK (char_length(title) <= 80),
  content text NOT NULL DEFAULT '' CHECK (char_length(content) <= 100000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.creations TO authenticated;
GRANT ALL ON public.creations TO service_role;
ALTER TABLE public.creations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own creations" ON public.creations FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);