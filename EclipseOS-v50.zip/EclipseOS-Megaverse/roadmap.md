# EclipseOS roadmap

- [x] v9.1 Shadow OS interface, forge, army, gates, wiki, terminal, brain
- [x] Accounts: email, Google, Apple, Microsoft sign-in + hunter profile
- [x] ECLIP wallet, daily reward functions, roles, surveys, announcements, creations schema
- [x] v50 Shadow Arcade: SWAT + 20 new games, catalog, filters, favorites, records
- [ ] v50 dashboard: avatar upload/editor, ECLIP reward, challenges, expanded records/calendar
- [x] v50 RGB Lab: 8 modes, pulse, glow
- [ ] v50 Seoul weather and ARCHK emoji token expansion
- [ ] v50 auth visual overhaul with accurate provider marks and clear unavailable providers
- [ ] v50 navigation, mobile polish, full interactive verification
- [ ] Real payments — blocked until payment provider is selected
- [ ] Real custom-domain publishing for user creations — intentionally deferred
