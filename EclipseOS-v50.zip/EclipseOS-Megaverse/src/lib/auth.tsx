import type { User } from "@supabase/supabase-js";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

import { supabase } from "@/integrations/supabase/client";

const AuthContext = createContext<{ user: User | null; ready: boolean }>({ user: null, ready: false });

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      setReady(true);
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      void router.invalidate();
      if (event !== "SIGNED_OUT") void queryClient.invalidateQueries();
    });
    void supabase.auth.getSession().then(({ data: s }) => { setUser(s.session?.user ?? null); setReady(true); });
    return () => data.subscription.unsubscribe();
  }, [router, queryClient]);

  return <AuthContext.Provider value={{ user, ready }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);

export function useProfile() {
  const { user } = useAuth();
  return useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export const XP_PER_LEVEL = 500;

/** Saves a game score and grants XP. Returns the new level and whether the hunter leveled up. */
export async function awardXp(userId: string, game: string, score: number) {
  const gain = Math.min(500, Math.round(score / 5) + 10);
  await supabase.from("game_scores").insert({ user_id: userId, game, score });
  const { data } = await supabase.from("profiles").select("xp, level").eq("id", userId).maybeSingle();
  const xp = (data?.xp ?? 0) + gain;
  const level = 1 + Math.floor(xp / XP_PER_LEVEL);
  await supabase.from("profiles").update({ xp, level, updated_at: new Date().toISOString() }).eq("id", userId);
  return { gain, level, leveledUp: level > (data?.level ?? 1) };
}

export const CREATOR_EMAIL = "shadowcorpcompany@gmail.com";

/** 👑 True when the signed-in user holds the admin role (checked in the database). */
export function useIsAdmin() {
  const { user } = useAuth();
  const { data } = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("has_role", { _user_id: user!.id, _role: "admin" });
      if (error) return false;
      return !!data;
    },
  });
  return !!data;
}
