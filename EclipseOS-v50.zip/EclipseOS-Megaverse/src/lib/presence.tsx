import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

import { supabase } from "@/integrations/supabase/client";
import { useAuth, useProfile } from "@/lib/auth";

export type OnlineHunter = { key: string; name: string; emoji: string; hue: string; level: number; guest: boolean };
const PresenceContext = createContext<OnlineHunter[]>([]);

/** 🟢 Live "who is online" using realtime presence (no table needed). */
export function PresenceProvider({ children }: { children: ReactNode }) {
  const { user, ready } = useAuth();
  const { data: profile } = useProfile();
  const [online, setOnline] = useState<OnlineHunter[]>([]);

  useEffect(() => {
    if (!ready) return;
    const key = user?.id ?? `guest-${Math.random().toString(36).slice(2, 8)}`;
    const channel = supabase.channel("eclipse-online", { config: { presence: { key } } });
    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState<Omit<OnlineHunter, "key">>();
        setOnline(Object.entries(state).map(([k, metas]) => ({ key: k, ...(metas[0] as unknown as Omit<OnlineHunter, "key">) })));
      })
      .subscribe((status) => {
        if (status !== "SUBSCRIBED") return;
        void channel.track({
          name: profile?.hunter_name ?? (user ? "Hunter" : "Guest"),
          emoji: profile?.avatar_emoji ?? "👤",
          hue: profile?.avatar_color ?? "190",
          level: profile?.level ?? 1,
          guest: !user,
        });
      });
    return () => { void supabase.removeChannel(channel); };
  }, [ready, user, profile?.hunter_name, profile?.avatar_emoji, profile?.avatar_color, profile?.level]);

  return <PresenceContext.Provider value={online}>{children}</PresenceContext.Provider>;
}

export const useOnline = () => useContext(PresenceContext);
