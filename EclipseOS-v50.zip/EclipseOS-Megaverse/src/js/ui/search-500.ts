export type MegaUnit = { id: number; name: string; type: string; status: string };

const districts = ["Gangnam", "Mapo", "Jongno", "Yongsan", "Songpa", "Seongdong"];
const types = ["SCP NODE", "SHADOW UNIT", "ARCHK MODULE", "SEOUL SECTOR"];

export function createMegaUnits(): MegaUnit[] {
  return Array.from({ length: 500 }, (_, index) => ({
    id: index + 1,
    name: `${districts[index % districts.length] ?? "Seoul"}-${String(index + 1).padStart(3, "0")}`,
    type: types[index % types.length] ?? "ARCHK MODULE",
    status: index % 11 === 0 ? "WATCH" : "ONLINE",
  }));
}

export function filterMegaUnits(units: MegaUnit[], query: string) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return units;
  return units.filter((unit) => `${unit.name} ${unit.type} ${unit.status}`.toLowerCase().includes(normalized));
}
