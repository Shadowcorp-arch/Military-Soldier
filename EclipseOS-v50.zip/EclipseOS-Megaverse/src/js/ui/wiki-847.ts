export type WikiCommand = { id: number; command: string; section: string; emoji: string; description: string };
const roots = ["flow", "summon", "scan", "forge", "bind", "trace", "shield", "render"];
const sections = ["世界创建", "智能创建", "系统创建", "网络创建", "交互"];
const emojis = ["🌊", "⚔️", "🏙️", "🧠", "▶️"];

export function createWikiCommands(): WikiCommand[] {
  return Array.from({ length: 847 }, (_, index) => ({
    id: index + 1,
    command: `${roots[index % roots.length] ?? "system"}.${String(index + 1).padStart(3, "0")}`,
    section: sections[index % sections.length] ?? "系统创建",
    emoji: emojis[index % emojis.length] ?? "▶️",
    description: `ARCHK protocol ${index + 1} for safe megaverse operations.`,
  }));
}

export function getVirtualRows(rows: WikiCommand[], scrollTop: number, viewportHeight: number, rowHeight = 42) {
  const start = Math.max(0, Math.floor(scrollTop / rowHeight) - 5);
  const visible = Math.ceil(viewportHeight / rowHeight) + 10;
  return { start, rows: rows.slice(start, start + Math.min(50, visible)), totalHeight: rows.length * rowHeight };
}
