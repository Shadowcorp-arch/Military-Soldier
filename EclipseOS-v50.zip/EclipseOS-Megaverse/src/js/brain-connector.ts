export async function askLys(question: string, signal?: AbortSignal) {
  try {
    const response = await fetch(`http://localhost:8000/lys?q=${encodeURIComponent(question)}`, signal ? { signal } : {});
    if (!response.ok) throw new Error("brain offline");
    const data = await response.json() as { answer?: string };
    return { online: true, answer: data.answer ?? "LYS: señal recibida." };
  } catch {
    return { online: false, answer: localLys(question) };
  }
}

function localLys(question: string) {
  const expression = question.match(/^[\d\s()+\-*/.]+$/)?.[0];
  if (expression) {
    const tokens = expression.trim().split(/\s+/);
    if (tokens.length === 3) {
      const left = Number(tokens[0]); const right = Number(tokens[2]); const op = tokens[1];
      const value = op === "+" ? left + right : op === "-" ? left - right : op === "*" ? left * right : op === "/" && right !== 0 ? left / right : null;
      if (value !== null && Number.isFinite(value)) return `Resultado táctico: ${value}.`;
    }
  }
  return "Cerebro local activo. Estoy contigo, Sung. Indica la operación.";
}
