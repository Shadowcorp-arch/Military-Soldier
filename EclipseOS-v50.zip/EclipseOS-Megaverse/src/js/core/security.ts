const PREFIX = "eclipseos:";

export const safeStorage = {
  get(key: string, fallback = "") {
    if (typeof window === "undefined") return fallback;
    try {
      return window.localStorage.getItem(`${PREFIX}${key}`) ?? fallback;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: string) {
    if (typeof window === "undefined" || value.length > 10_000) return false;
    try {
      window.localStorage.setItem(`${PREFIX}${key}`, value);
      return true;
    } catch {
      return false;
    }
  },
};

export function safeText(value: unknown, max = 500) {
  return String(value ?? "").replace(/[<>]/g, "").slice(0, max);
}
