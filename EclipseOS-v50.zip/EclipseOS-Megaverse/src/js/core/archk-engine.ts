export type ArchkEntity = "river" | "mountain" | "city";

const syntax: Record<string, ArchkEntity> = { "🌊": "river", "🏔️": "mountain", "🏙️": "city" };

export function parseArchk(source: string) {
  const entities = Object.entries(syntax)
    .filter(([emoji]) => source.includes(emoji))
    .map(([, entity]) => entity);
  const valid = source.trim().length > 0 && source.length <= 10_000;
  return { valid, entities, message: valid ? `COMPILED // ${entities.length} WORLD ENTITIES` : "REJECTED // EMPTY OR OVERSIZED INPUT" };
}

export function drawWorld(canvas: HTMLCanvasElement, entities: ArchkEntity[], tick: number) {
  const context = canvas.getContext("2d");
  if (!context) return;
  const { width, height } = canvas;
  context.clearRect(0, 0, width, height);
  context.fillStyle = "#050914";
  context.fillRect(0, 0, width, height);
  if (entities.includes("city")) {
    for (let x = 12; x < width; x += 26) {
      const buildingHeight = 28 + ((x * 7) % 62);
      context.fillStyle = "#12283c";
      context.fillRect(x, height - 42 - buildingHeight, 18, buildingHeight);
      context.fillStyle = x % 52 ? "#17d9ed" : "#d72e47";
      context.fillRect(x + 4, height - 34 - buildingHeight, 3, 3);
    }
  }
  if (entities.includes("mountain")) {
    context.strokeStyle = "#8393aa";
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(0, height - 38);
    context.lineTo(width * .28, height * .35);
    context.lineTo(width * .48, height - 42);
    context.lineTo(width * .72, height * .22);
    context.lineTo(width, height - 38);
    context.stroke();
  }
  if (entities.includes("river")) {
    context.strokeStyle = "#18d9f0";
    context.lineWidth = 2;
    for (let y = height - 34; y < height; y += 8) {
      context.beginPath();
      for (let x = 0; x <= width; x += 8) {
        const wave = Math.sin(x / 22 + tick / 15 + y) * 3;
        if (x === 0) context.moveTo(x, y + wave);
        else context.lineTo(x, y + wave);
      }
      context.stroke();
    }
  }
}
