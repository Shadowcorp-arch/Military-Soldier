export const languages = {
  "es-mx": { system: "SISTEMA", nexus: "NEXUS DE SEÚL", missions: "MISIONES", arise: "SURGE" },
  "es-es": { system: "SISTEMA", nexus: "NEXO DE SEÚL", missions: "MISIONES", arise: "ÁLZATE" },
  en: { system: "SYSTEM", nexus: "SEOUL NEXUS", missions: "MISSIONS", arise: "ARISE" },
  ko: { system: "시스템", nexus: "서울 넥서스", missions: "임무", arise: "일어나라" },
  jp: { system: "システム", nexus: "ソウル・ネクサス", missions: "任務", arise: "起きろ" },
  cn: { system: "系统", nexus: "首尔枢纽", missions: "任务", arise: "苏醒" },
  pt: { system: "SISTEMA", nexus: "NEXO DE SEUL", missions: "MISSÕES", arise: "ERGA-SE" },
  fr: { system: "SYSTÈME", nexus: "NEXUS DE SÉOUL", missions: "MISSIONS", arise: "LÈVE-TOI" },
  de: { system: "SYSTEM", nexus: "SEOUL-NEXUS", missions: "MISSIONEN", arise: "ERHEBE DICH" },
  it: { system: "SISTEMA", nexus: "NEXUS DI SEUL", missions: "MISSIONI", arise: "SORGI" },
  ru: { system: "СИСТЕМА", nexus: "НЕКСУС СЕУЛА", missions: "МИССИИ", arise: "ВОССТАНЬ" },
  ar: { system: "النظام", nexus: "نيكسوس سيول", missions: "المهام", arise: "انهض" },
  hi: { system: "सिस्टम", nexus: "सियोल नेक्सस", missions: "मिशन", arise: "उठो" },
  tr: { system: "SİSTEM", nexus: "SEUL NEXUS", missions: "GÖREVLER", arise: "YÜKSEL" },
} as const;
export type Language = keyof typeof languages;
export const languageCodes = Object.keys(languages) as Language[];
