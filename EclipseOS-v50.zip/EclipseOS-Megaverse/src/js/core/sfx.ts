// 🔊 ECLIPSE SFX — offline synth sounds, no audio files needed
import { safeStorage } from "./security";

let ctx: AudioContext | null = null;

export function isMuted() {
  return safeStorage.get("muted", "0") === "1";
}
export function setMuted(muted: boolean) {
  safeStorage.set("muted", muted ? "1" : "0");
}

function tone(freq: number, dur = 0.12, type: OscillatorType = "square", vol = 0.05, slideTo?: number, delay = 0) {
  if (typeof window === "undefined" || isMuted()) return;
  try {
    ctx ??= new AudioContext();
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    gain.gain.setValueAtTime(vol, t);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain).connect(ctx.destination);
    osc.start(t);
    osc.stop(t + dur + 0.02);
  } catch {
    /* audio unavailable */
  }
}

export const sfx = {
  click: () => tone(880, 0.05, "square", 0.03),
  hover: () => tone(1320, 0.03, "sine", 0.015),
  coin: () => { tone(988, 0.07, "square", 0.04); tone(1319, 0.12, "square", 0.04, undefined, 0.07); },
  flap: () => tone(420, 0.09, "triangle", 0.05, 720),
  hit: () => tone(180, 0.3, "sawtooth", 0.07, 60),
  whoosh: () => tone(200, 0.25, "sine", 0.05, 900),
  levelUp: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.14, "square", 0.04, undefined, i * 0.09)),
  success: () => [660, 880].forEach((f, i) => tone(f, 0.1, "triangle", 0.05, undefined, i * 0.08)),
  shoot: () => tone(260, 0.07, "sawtooth", 0.05, 90),
  silenced: () => tone(900, 0.04, "triangle", 0.03, 300),
  reload: () => { tone(320, 0.05, "square", 0.03); tone(520, 0.06, "square", 0.03, undefined, 0.18); },
  alarm: () => [0, 0.25, 0.5].forEach((d) => tone(740, 0.2, "sawtooth", 0.035, 520, d)),
  boot: () => [196, 262, 392, 523, 784].forEach((f, i) => tone(f, 0.22, "sine", 0.04, undefined, i * 0.12)),
  notify: () => { tone(1175, 0.08, "sine", 0.04); tone(1568, 0.12, "sine", 0.04, undefined, 0.09); },
  purchase: () => [784, 988, 1175, 1568].forEach((f, i) => tone(f, 0.08, "square", 0.035, undefined, i * 0.06)),
  type: () => tone(1800 + Math.random() * 400, 0.015, "square", 0.012),
  extract: () => [392, 523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.16, "triangle", 0.045, undefined, i * 0.08)),
};
