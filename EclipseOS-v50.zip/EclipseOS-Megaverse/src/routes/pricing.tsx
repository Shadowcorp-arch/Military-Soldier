import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";

export const Route = createFileRoute("/pricing")({
  head: () => ({ meta: [
    { title: "Plans & Pricing — ECLIPSEOS" },
    { name: "description", content: "Free, Hunter and Monarch plans: games, XP boosts, website builder and custom domains." },
    { property: "og:title", content: "Plans & Pricing — ECLIPSEOS" },
    { property: "og:description", content: "Choose your rank: Free, Hunter or Monarch." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Pricing,
});

const PLANS = [
  { name: "E-RANK", price: "0", tag: "FREE", features: ["All 4 official games", "Hunter profile & XP", "RGB lab & 4 themes", "ARCHK compiler"] },
  { name: "HUNTER", price: "4.99", tag: "POPULAR", featured: true, features: ["Everything in Free", "XP x1.5 boost", "1 website in the builder", "eclipse subdomain", "Exclusive RGB presets"] },
  { name: "MONARCH", price: "14.99", tag: "PRO", features: ["Everything in Hunter", "XP x2 boost", "5 websites + custom domains", "Priority support", "Early access to seasons"] },
];

function Pricing() {
  return (
    <SiteShell>
      <PageHero eyebrow="RANK UPGRADE // PLANS" title="CHOOSE YOUR RANK" text="Build websites inside ECLIPSEOS, connect your own domain and boost your progress." />
      <div className="grid-3">
        {PLANS.map((p) => (
          <div key={p.name} className={`panel plan ${p.featured ? "featured" : ""}`}>
            <small className="text-primary text-xs tracking-widest">{p.tag}</small>
            <h2>{p.name}</h2>
            <div className="price">${p.price}<small>/month</small></div>
            <ul>{p.features.map((f) => <li key={f}>{f}</li>)}</ul>
            {p.price === "0" ? <Link to="/auth"><Button variant="outline" className="w-full">START FREE</Button></Link> : <Button onClick={() => toast("Payments are coming soon!")}>COMING SOON</Button>}
          </div>
        ))}
      </div>
    </SiteShell>
  );
}
