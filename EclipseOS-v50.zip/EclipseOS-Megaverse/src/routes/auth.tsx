import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FormEvent, useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";
import { lovable } from "@/integrations/lovable/index";
import { supabase } from "@/integrations/supabase/client";
import { sfx } from "@/js/core/sfx";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [
    { title: "Sign in or create account — ECLIPSEOS" },
    { name: "description", content: "Create your ECLIPSEOS hunter account with email, Google, Apple or Microsoft." },
    { property: "og:title", content: "Join ECLIPSEOS" },
    { property: "og:description", content: "Create your hunter account and start leveling up." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: AuthPage,
});

const G = () => <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4-5.5 4-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.4 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12s4.3 9.6 9.6 9.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z" /></svg>;
const A = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16.4 12.6c0-2.6 2.1-3.8 2.2-3.9-1.2-1.8-3.1-2-3.7-2-1.6-.2-3.1.9-3.9.9-.8 0-2-.9-3.4-.9-1.7 0-3.3 1-4.2 2.6-1.8 3.1-.5 7.7 1.3 10.2.9 1.2 1.9 2.6 3.2 2.6 1.3-.1 1.8-.8 3.3-.8 1.6 0 2 .8 3.4.8 1.4 0 2.3-1.3 3.1-2.5 1-1.4 1.4-2.8 1.4-2.9-.1 0-2.7-1-2.7-4.1zM13.9 5c.7-.9 1.2-2 1.1-3.2-1 0-2.3.7-3 1.6-.7.8-1.3 2-1.1 3.1 1.1.1 2.3-.6 3-1.5z" /></svg>;
const M = () => <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#F25022" d="M2 2h9.5v9.5H2z" /><path fill="#7FBA00" d="M12.5 2H22v9.5h-9.5z" /><path fill="#00A4EF" d="M2 12.5h9.5V22H2z" /><path fill="#FFB900" d="M12.5 12.5H22V22h-9.5z" /></svg>;

function AuthPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"in" | "up" | "forgot">("in");
  const [msg, setMsg] = useState<{ text: string; err?: boolean } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (user) void navigate({ to: "/dashboard" }); }, [user, navigate]);

  async function social(provider: "google" | "apple" | "microsoft") {
    sfx.click();
    const r = await lovable.auth.signInWithOAuth(provider, { redirect_uri: window.location.origin + "/auth" });
    if (r.error) setMsg({ text: r.error.message ?? "Sign-in failed", err: true });
  }

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const f = new FormData(e.currentTarget);
    const email = String(f.get("email") ?? "").trim(); const password = String(f.get("password") ?? "");
    try {
      if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error; setMsg({ text: "Check your email for a reset link." });
      } else if (mode === "up") {
        const hunter = String(f.get("hunter") ?? "").trim().slice(0, 30) || "Hunter";
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { hunter_name: hunter } } });
        if (error) throw error; sfx.success(); setMsg({ text: "Account created! Check your email to confirm, then sign in." });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error; sfx.levelUp();
      }
    } catch (err) { sfx.hit(); setMsg({ text: err instanceof Error ? err.message : "Something went wrong", err: true }); }
    setBusy(false);
  }

  return (
    <SiteShell>
      <PageHero eyebrow="HUNTER REGISTRATION // SYSTEM WINDOW" title={mode === "up" ? "AWAKEN" : mode === "forgot" ? "RECOVER" : "ENTER"} text="Your hunter profile saves your level, XP, RGB style and game scores." />
      <div className="panel auth-card">
        {mode !== "forgot" && <div className="auth-tabs"><button className={mode === "in" ? "active" : ""} onClick={() => setMode("in")}>SIGN IN</button><button className={mode === "up" ? "active" : ""} onClick={() => setMode("up")}>CREATE ACCOUNT</button></div>}
        {mode !== "forgot" && <>
          <div className="social-grid">
            <button className="social-btn" onClick={() => social("google")}><G /> Google</button>
            <button className="social-btn" onClick={() => social("apple")}><A /> Apple</button>
            <button className="social-btn" onClick={() => social("microsoft")}><M /> Microsoft</button>
          </div>
          <div className="social-grid">
            {["GitHub", "Xbox", "Discord"].map((p) => <button key={p} className="social-btn" disabled title="Coming soon">{p}</button>)}
          </div>
          <div className="divider">OR WITH EMAIL</div>
        </>}
        <form onSubmit={submit} className="grid gap-3">
          {mode === "up" && <label className="field">HUNTER NAME<input name="hunter" maxLength={30} placeholder="Sung Shadow" /></label>}
          <label className="field">EMAIL<input name="email" type="email" required autoComplete="email" /></label>
          {mode !== "forgot" && <label className="field">PASSWORD<input name="password" type="password" required minLength={6} autoComplete={mode === "up" ? "new-password" : "current-password"} /></label>}
          <Button type="submit" disabled={busy}>{busy ? "..." : mode === "up" ? "CREATE ACCOUNT" : mode === "forgot" ? "SEND RESET LINK" : "SIGN IN"}</Button>
        </form>
        {msg && <p className={`form-msg ${msg.err ? "err" : ""}`}>{msg.text}</p>}
        <button className="link-btn" onClick={() => { setMsg(null); setMode(mode === "forgot" ? "in" : "forgot"); }}>{mode === "forgot" ? "← Back to sign in" : "Forgot password?"}</button>
      </div>
    </SiteShell>
  );
}
