import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { ARCADE } from "@/components/eclipse/arcade";
import { GateRunner, KkamakFlight, RuneMemory, ShadowClicker } from "@/components/eclipse/games";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";
import { SwatExtraction } from "@/components/eclipse/SwatGame";
import { safeStorage } from "@/js/core/security";
import { sfx } from "@/js/core/sfx";
import { awardXp, useAuth } from "@/lib/auth";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/games")({
  head: () => ({ meta: [
    { title: "Shadow Arcade — 25 ECLIPSEOS Games" },
    { name: "description", content: "25 games: SWAT Extraction, Shadow Clicker, Gate Hunt, Rune Oracle and more. Earn XP and level up your hunter." },
    { property: "og:title", content: "Shadow Arcade — 25 ECLIPSEOS Games" },
    { property: "og:description", content: "Action, strategy, arcade, puzzle and simulation games. Earn XP and climb levels." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: GamesPage,
});

// Game ids are stored with scores: append-only, never reuse.
const GAMES = [
  { id: "swat", name: "🎯 SWAT EXTRACTION", family: "Acción", Comp: SwatExtraction },
  { id: "clicker", name: "⚔️ SHADOW CLICKER", family: "Arcade", Comp: ShadowClicker },
  { id: "memory", name: "🔮 RUNE MEMORY", family: "Puzzle", Comp: RuneMemory },
  { id: "flight", name: "🐦‍⬛ KKAMAK FLIGHT", family: "Arcade", Comp: KkamakFlight },
  { id: "runner", name: "🚪 GATE RUNNER", family: "Acción", Comp: GateRunner },
  ...ARCADE,
];
const FAMILIES = ["Todos", "★", "Acción", "Estrategia", "Arcade", "Puzzle", "Simulación"];

function GamesPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [active, setActive] = useState("swat");
  const [q, setQ] = useState("");
  const [fam, setFam] = useState("Todos");
  const [favs, setFavs] = useState<string[]>([]);
  const [best, setBest] = useState<Record<string, number>>({});
  const [xpFx, setXpFx] = useState<string | null>(null);
  useEffect(() => { try { setFavs(JSON.parse(safeStorage.get("favs", "[]"))); setBest(JSON.parse(safeStorage.get("best", "{}"))); } catch { /* ignore */ } }, []);
  const game = GAMES.find((g) => g.id === active)!;
  const list = useMemo(() => GAMES.filter((g) => (fam === "Todos" || g.family === fam || (fam === "★" && favs.includes(g.id))) && g.name.toLowerCase().includes(q.toLowerCase())), [q, fam, favs]);

  const toggleFav = (id: string) => { const n = favs.includes(id) ? favs.filter((f) => f !== id) : [...favs, id]; setFavs(n); safeStorage.set("favs", JSON.stringify(n)); sfx.click(); };

  const finish = useCallback(async (score: number) => {
    setBest((b) => { const n = score > (b[active] ?? 0) ? { ...b, [active]: score } : b; safeStorage.set("best", JSON.stringify(n)); return n; });
    if (!user) { toast(`Score ${score}! Sign in to save it and earn XP.`); return; }
    try {
      const r = await awardXp(user.id, active, score);
      setXpFx(`+${r.gain} XP`); window.setTimeout(() => setXpFx(null), 1400);
      if (r.leveledUp) { sfx.levelUp(); toast.success(`LEVEL UP! You are now level ${r.level}`); }
      else toast.success(`Score ${score} saved · +${r.gain} XP`);
      void qc.invalidateQueries({ queryKey: ["profile"] });
    } catch { toast.error("Could not save your score. Try again."); }
  }, [user, active, qc]);

  return (
    <SiteShell>
      <PageHero eyebrow="SHADOW ARCADE // 25 OFFICIAL GAMES" title="PLAY. EXTRACT. LEVEL UP." text="Action, strategy, arcade, puzzle and simulation. Every run grants XP to your hunter profile." />
      {!user && <div className="panel"><p>Playing as guest. <Link to="/auth" className="text-primary underline">Sign in</Link> to save scores and earn XP.</p></div>}
      <div className="arc-filters">
        <input placeholder="🔍 Search games…" value={q} onChange={(e) => setQ(e.target.value)} />
        {FAMILIES.map((f) => <button key={f} className={fam === f ? "active" : ""} onClick={() => { sfx.click(); setFam(f); }}>{f}</button>)}
      </div>
      <div className="arc-catalog">
        {list.map((g) => (
          <div key={g.id} className={`arc-card ${active === g.id ? "active" : ""}`} onClick={() => { sfx.whoosh(); setActive(g.id); }}>
            <b>{g.name}</b><small>{g.family} · 🏆 {best[g.id] ?? 0}</small>
            <button className="arc-fav" aria-label="Favorite" onClick={(e) => { e.stopPropagation(); toggleFav(g.id); }}>{favs.includes(g.id) ? "★" : "☆"}</button>
          </div>
        ))}
      </div>
      <div className="panel"><h2 className="arc-title">{game.name}</h2><game.Comp key={active} onFinish={finish} /></div>
      {xpFx && <div className="float-xp">{xpFx}</div>}
    </SiteShell>
  );
}
