import { createFileRoute } from "@tanstack/react-router";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [
    { title: "Docs, Help & Support — ECLIPSEOS" },
    { name: "description", content: "ECLIPSEOS docs: ARCHK emoji code, LYS brain, games, accounts, FAQ, credits and contact." },
    { property: "og:title", content: "Docs & Support — ECLIPSEOS" },
    { property: "og:description", content: "Learn ARCHK, the LYS brain and get help." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Support,
});

const DOCS: [string, string][] = [
  ["🚀 Getting started", "Create an account, pick your RGB style with the rainbow button in the corner, and play a game to earn your first XP."],
  ["🌍 ARCHK emoji code", "In the Dev Forge, emojis ARE code: 🌊 river, 🏔️ mountain, 🏙️ city, ⚔️ shadow army, 👤 human. Type them and the world preview draws live."],
  ["🧠 LYS brain", "LYS answers in the Forge chat. Run the optional local brain (python, port 8000) for tierna/capitana modes; without it she uses her offline brain."],
  ["🐦‍⬛ KKAMAK motor", "Click KKAMAK for his kraw. In the terminal, type 'kkamak escanear' to scan a sector."],
  ["🎮 Games & XP", "Every finished run grants XP. 500 XP = 1 level. Scores are saved to your dashboard."],
];
const FAQ: [string, string][] = [
  ["Is it free?", "Yes. The E-Rank plan is free forever. Paid plans are coming soon."],
  ["Can I sign in with GitHub, Xbox or Discord?", "Not yet. You can use email, Google, Apple or Microsoft today."],
  ["I did not get the confirmation email", "Check spam, then try signing up again with the same address."],
  ["How do I turn sounds off?", "Dashboard → Settings → Sound effects."],
];

function Support() {
  return (
    <SiteShell>
      <PageHero eyebrow="KNOWLEDGE BASE // HELP DESK" title="DOCS & SUPPORT" text="Tech docs, help, answers and the people behind ECLIPSEOS." />
      <div className="grid-3">{DOCS.map(([h, p]) => <div key={h} className="panel"><h3>{h}</h3><p>{p}</p></div>)}</div>
      <div className="grid-2">
        <div className="panel"><h2>FAQ</h2>
          <Accordion type="single" collapsible>{FAQ.map(([q, a]) => <AccordionItem key={q} value={q}><AccordionTrigger>{q}</AccordionTrigger><AccordionContent>{a}</AccordionContent></AccordionItem>)}</Accordion>
        </div>
        <div className="panel"><h2>CONTACT</h2>
          <p>Need help? Write to <b className="text-primary">support@eclipseos.app</b>. We answer within 48 hours.</p>
          <p className="mt-3">Tech stack: React, TanStack, Tailwind, canvas games, offline synth audio, optional Python FastAPI brain.</p>
        </div>
      </div>
      <div className="panel" id="credits"><h2>CREDITS</h2>
        <p>Creator & owner: <b>Sung Shadow</b> (LVL 11). Captain: <b>LYS 22</b>. Motor: <b>KKAMAK</b>, 30cm, 500 years old. Shadow Army: Igris, Beru, Tusk.</p>
        <p className="mt-2">Built with love in the Seoul Megaverse. 🌑⚔️🐦‍⬛</p>
      </div>
    </SiteShell>
  );
}
