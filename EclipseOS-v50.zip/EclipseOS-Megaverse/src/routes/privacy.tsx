import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/eclipse/LegalPage";

export const Route = createFileRoute("/privacy")({
  head: () => ({ meta: [
    { title: "Privacy Policy — ECLIPSEOS" },
    { name: "description", content: "What data ECLIPSEOS collects, why, and how you control it." },
    { property: "og:title", content: "Privacy Policy — ECLIPSEOS" },
    { property: "og:description", content: "How ECLIPSEOS handles your data." },
    { property: "og:type", content: "article" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <LegalPage title="PRIVACY POLICY" updated="SEP 2026" sections={[
    ["What we collect", "Your email, hunter name, optional avatar link, level, XP, style preferences and game scores. If you sign in with Google, Apple or Microsoft we receive your basic profile (name and email)."],
    ["Why", "To run your account, save your progress and show your stats. We do not sell your data."],
    ["Local storage", "Theme, RGB and sound preferences are also kept in your browser so the site remembers them offline."],
    ["Security", "Access to your profile and scores is restricted to your own account."],
    ["Your rights", "You can edit your profile at any time from the dashboard and request deletion of your account through Support."],
    ["Children", "ECLIPSEOS is not directed to children under 13."],
  ]} />,
});
