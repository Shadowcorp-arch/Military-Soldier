import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FormEvent, useState } from "react";

import { Button } from "@/components/ui/button";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "Reset password — ECLIPSEOS" },
    { name: "description", content: "Choose a new password for your ECLIPSEOS hunter account." },
    { property: "og:title", content: "Reset password — ECLIPSEOS" },
    { property: "og:description", content: "Set a new password for your hunter account." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: ResetPage,
});

function ResetPage() {
  const navigate = useNavigate();
  const [msg, setMsg] = useState<string | null>(null);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const password = String(new FormData(e.currentTarget).get("password") ?? "");
    const { error } = await supabase.auth.updateUser({ password });
    if (error) { setMsg(error.message); return; }
    void navigate({ to: "/dashboard" });
  }
  return (
    <SiteShell>
      <PageHero eyebrow="ACCOUNT RECOVERY" title="NEW PASSWORD" />
      <form onSubmit={submit} className="panel auth-card">
        <label className="field">NEW PASSWORD<input name="password" type="password" minLength={6} required autoComplete="new-password" /></label>
        <Button type="submit">UPDATE PASSWORD</Button>
        {msg && <p className="form-msg err">{msg}</p>}
      </form>
    </SiteShell>
  );
}
