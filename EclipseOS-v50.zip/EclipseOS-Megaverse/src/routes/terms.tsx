import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/eclipse/LegalPage";

export const Route = createFileRoute("/terms")({
  head: () => ({ meta: [
    { title: "Terms of Service — ECLIPSEOS" },
    { name: "description", content: "The rules for using ECLIPSEOS, its games and hunter accounts." },
    { property: "og:title", content: "Terms of Service — ECLIPSEOS" },
    { property: "og:description", content: "Rules for using ECLIPSEOS." },
    { property: "og:type", content: "article" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <LegalPage title="TERMS OF SERVICE" updated="SEP 2026" sections={[
    ["1. Acceptance", "By creating a hunter account or using ECLIPSEOS you agree to these terms. If you do not agree, please do not use the service."],
    ["2. Accounts", "You are responsible for your account and for keeping your password safe. One person per account. We may suspend accounts that abuse the service, cheat in games, or harass others."],
    ["3. Acceptable use", "Do not attempt to break, overload, reverse engineer or attack the platform. Do not upload illegal, hateful or infringing content."],
    ["4. Games and XP", "XP, levels and scores are for entertainment. They have no monetary value and may be reset or rebalanced."],
    ["5. Paid plans", "Paid plans, when available, renew automatically until cancelled. Prices and features may change with notice."],
    ["6. Liability", "ECLIPSEOS is provided \"as is\" without warranties. To the extent allowed by law we are not liable for indirect damages."],
    ["7. Changes", "We may update these terms. Continued use after changes means you accept the new terms."],
  ]} />,
});
