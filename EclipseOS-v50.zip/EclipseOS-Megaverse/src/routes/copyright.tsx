import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/eclipse/LegalPage";

export const Route = createFileRoute("/copyright")({
  head: () => ({ meta: [
    { title: "Copyright — ECLIPSEOS" },
    { name: "description", content: "Copyright and ownership of ECLIPSEOS characters, artwork and code." },
    { property: "og:title", content: "Copyright — ECLIPSEOS" },
    { property: "og:description", content: "Ownership of ECLIPSEOS characters and artwork." },
    { property: "og:type", content: "article" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <LegalPage title="COPYRIGHT" updated="SEP 2026" sections={[
    ["Ownership", "© 2026 ECLIPSEOS · Sung Shadow. The ECLIPSEOS name, logo, the characters LYS 22 and KKAMAK, the ARCHK language, artwork, sounds and code are original works. All rights reserved."],
    ["Allowed use", "You may share screenshots and clips of ECLIPSEOS for non-commercial fan content with credit."],
    ["Not allowed", "Copying, reselling or redistributing the artwork, logo or code without written permission."],
    ["Takedown requests", "If you believe content here infringes your rights, contact us through the Support page with details."],
  ]} />,
});
