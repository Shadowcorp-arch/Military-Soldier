import { createFileRoute, Link } from "@tanstack/react-router";
import { AccountButton, OnlineBadge, SiteFooter, SiteLogo } from "@/components/eclipse/SiteShell";
import { Activity, ChevronRight, CircleDot, Command, Cpu, Languages, LockKeyhole, Radio, Search, Shield, Sparkles, Terminal as TerminalIcon, Volume2, X } from "lucide-react";
import { FormEvent, MouseEvent, useEffect, useMemo, useRef, useState } from "react";

import seoulImage from "@/assets/eclipse-seoul.jpg";
import kkamakImage from "@/assets/kkamak-sprite.png";
import lysImage from "@/assets/lys-sprite.png";
import armyImage from "@/assets/shadow-army.jpg";
import { Button } from "@/components/ui/button";
import { askLys } from "@/js/brain-connector";
import { drawWorld, parseArchk } from "@/js/core/archk-engine";
import { languageCodes, languages, type Language } from "@/js/core/i18n";
import { safeStorage, safeText } from "@/js/core/security";
import { createMegaUnits, filterMegaUnits } from "@/js/ui/search-500";
import { createWikiCommands, getVirtualRows } from "@/js/ui/wiki-847";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "ECLIPSEOS v9.1 MONARCH — Seoul Megaverse Shadow OS" },
    { name: "description", content: "ECLIPSEOS v9.1: Shadow Army command, ARCHK compiler, Seoul gates, LYS brain and KKAMAK motor." },
    { property: "og:title", content: "ECLIPSEOS v9.1 MONARCH" },
    { property: "og:description", content: "Enter the Seoul Megaverse Shadow OS." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: EclipseOS,
});

const initialCode = `🌍 world seoul_megaverse {
  🌊 river_main = { width: 800, flow: 0.8 }
  🏔️ mount_bukhansan = { height: 836 }
  🏙️ city_seoul = { district: gangnam }
  ⚔️ shadow_army = { igris, beru, tusk, lys, kkamak }
  👤 owner = { sung_shadow, level: 11 }
}`;

const themes = ["shadow", "void", "crimson", "aurora"] as const;
type Theme = typeof themes[number];
const army = [
  { name: "IGRIS", rank: "MARSHAL", stat: "9,840", role: "SWORD / GUARD" },
  { name: "BERU", rank: "GENERAL", stat: "9,620", role: "SPEED / HUNT" },
  { name: "TUSK", rank: "GENERAL", stat: "9,410", role: "MAGIC / SIEGE" },
];

function EclipseOS() {
  const [theme, setTheme] = useState<Theme>("shadow");
  const [language, setLanguage] = useState<Language>("es-mx");
  const [arisen, setArisen] = useState(false);
  const [query, setQuery] = useState("");
  const [code, setCode] = useState(initialCode);
  const [compileCount, setCompileCount] = useState(0);
  const [compileMessage, setCompileMessage] = useState("READY // ARCHK INPUT REQUIRED");
  const [activeForge, setActiveForge] = useState("archk");
  const [chat, setChat] = useState([{ by: "LYS", text: "Bienvenido, Sung. Los dos cerebros están sincronizados." }]);
  const [brainOnline, setBrainOnline] = useState<boolean | null>(null);
  const [wikiQuery, setWikiQuery] = useState("");
  const [wikiScroll, setWikiScroll] = useState(0);
  const [terminalLines, setTerminalLines] = useState(["ECLIPSEOS KERNEL 9.1.0", "SECURE SHELL READY // TYPE HELP"]);
  const [gateResult, setGateResult] = useState("GATE CONTROL READY // SELECT A NODE");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particleRef = useRef<HTMLCanvasElement>(null);
  const heroRef = useRef<HTMLElement>(null);
  const units = useMemo(createMegaUnits, []);
  const wiki = useMemo(createWikiCommands, []);
  const filteredUnits = useMemo(() => filterMegaUnits(units, query), [units, query]);
  const filteredWiki = useMemo(() => wiki.filter((row) => `${row.command} ${row.section} ${row.description}`.toLowerCase().includes(wikiQuery.toLowerCase())), [wiki, wikiQuery]);
  const virtual = getVirtualRows(filteredWiki, wikiScroll, 420);
  const parsed = useMemo(() => parseArchk(code), [code]);
  const t = languages[language];

  useEffect(() => {
    const stored = safeStorage.get("theme", "shadow");
    if (themes.includes(stored as Theme)) setTheme(stored as Theme);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let frame = 0;
    let animation = 0;
    const render = () => { drawWorld(canvas, parsed.entities, frame++); animation = requestAnimationFrame(render); };
    render();
    return () => cancelAnimationFrame(animation);
  }, [parsed.entities]);

  useEffect(() => {
    const canvas = particleRef.current;
    const hero = heroRef.current;
    if (!canvas || !hero) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    const points = Array.from({ length: 54 }, (_, i) => ({ x: (i * 83) % 1200, y: (i * 137) % 760, speed: .35 + (i % 5) * .14, size: 1 + i % 3 }));
    let animation = 0;
    const resize = () => { canvas.width = hero.clientWidth; canvas.height = hero.clientHeight; };
    const render = () => {
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.fillStyle = "rgba(31, 226, 241, .55)";
      points.forEach((point) => { point.y -= point.speed; if (point.y < -5) point.y = canvas.height + 5; point.x %= canvas.width || 1; context.fillRect(point.x, point.y, point.size, point.size * 4); });
      animation = requestAnimationFrame(render);
    };
    resize(); render(); window.addEventListener("resize", resize);
    return () => { cancelAnimationFrame(animation); window.removeEventListener("resize", resize); };
  }, []);

  function playSignal(path: string, frequency: number) {
    const audio = new Audio(path);
    void audio.play().catch(() => {
      const AudioContextCtor = window.AudioContext;
      const context = new AudioContextCtor(); const oscillator = context.createOscillator(); const gain = context.createGain();
      oscillator.frequency.value = frequency; oscillator.type = "sawtooth"; gain.gain.setValueAtTime(.08, context.currentTime); gain.gain.exponentialRampToValueAtTime(.001, context.currentTime + .35);
      oscillator.connect(gain).connect(context.destination); oscillator.start(); oscillator.stop(context.currentTime + .35);
    });
  }

  function handleArise() {
    setArisen(true); playSignal("/audio/arise.mp3", 72);
    setTerminalLines((lines) => [...lines, "> arise", "SHADOW EXTRACTION COMPLETE // 500 UNITS AWAIT"]);
    window.setTimeout(() => setArisen(false), 950);
  }

  function handleHeroMove(event: MouseEvent<HTMLElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - .5; const y = (event.clientY - rect.top) / rect.height - .5;
    event.currentTarget.style.setProperty("--mouse-x", `${x * 18}px`); event.currentTarget.style.setProperty("--mouse-y", `${y * 12}px`);
  }

  async function handleChat(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget); const question = safeText(form.get("message"), 240).trim(); if (!question) return;
    setChat((messages) => [...messages, { by: "SUNG", text: question }]); event.currentTarget.reset();
    const result = await askLys(question); setBrainOnline(result.online); setChat((messages) => [...messages, { by: "LYS", text: result.answer }]);
  }

  function runTerminal(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); const form = new FormData(event.currentTarget); const command = safeText(form.get("command"), 80).trim().toLowerCase(); event.currentTarget.reset(); if (!command) return;
    if (command === "clear") { setTerminalLines([]); return; }
    const replies: Record<string, string> = {
      arise: "SHADOW ARMY ONLINE // IGRIS BERU TUSK",
      compile: parseArchk(code).message,
      "lys report": `LYS 22 // TIERNA-CAPITANA // ${brainOnline ? "DUAL BRAIN ONLINE" : "LOCAL BRAIN"}`,
      "kkamak escanear": "SECTOR SCAN CLEAN // YELLOW EYE ACTIVE",
      help: "COMMANDS: arise | compile | lys report | kkamak escanear | clear",
    };
    setTerminalLines((lines) => [...lines, `> ${command}`, replies[command] ?? "UNKNOWN COMMAND // ACCESS DENIED"]);
  }

  return (
    <div className={`eclipse-app theme-${theme}`}>
      <div className="scanline" aria-hidden="true" />
      <header className="command-header">
        <SiteLogo />
        <nav aria-label="Navegación principal">
          <a href="#forge">FORGE</a><a href="#army">ARMY</a><Link to="/games">GAMES</Link><Link to="/pricing">PLANS</Link><Link to="/support">SUPPORT</Link>
        </nav>
        <div className="header-tools">
          <OnlineBadge />
          <AccountButton />
          <label><Languages size={14} /><select value={language} onChange={(event) => setLanguage(event.target.value as Language)} aria-label="Language">{languageCodes.map((code) => <option key={code} value={code}>{code.toUpperCase()}</option>)}</select></label>
          <label><CircleDot size={12} /><select value={theme} onChange={(event) => { const next = event.target.value as Theme; setTheme(next); safeStorage.set("theme", next); }} aria-label="Theme"><option value="shadow">SHADOW</option><option value="void">VOID</option><option value="crimson">CRIMSON</option><option value="aurora">AURORA</option></select></label>
        </div>
      </header>

      <main>
        <section ref={heroRef} onMouseMove={handleHeroMove} className="hero" id="home">
          <img src={seoulImage} width={1600} height={1000} alt="Cyberpunk Seoul beneath a supernatural eclipse" className="hero-image" />
          <canvas ref={particleRef} className="particle-canvas" aria-hidden="true" />
          <div className="hero-shade" />
          <div className="hero-copy">
            <p className="eyebrow"><Radio size={13} /> SEOUL MEGAVERSE // SHADOW OS</p>
            <p className="system-kicker">[ {t.system} WINDOW 001 ]</p>
            <h1 className={arisen ? "glitch active" : "glitch"} data-text="ECLIPSEOS">ECLIPSE<span>OS</span></h1>
            <p className="version">MONARCH <b>v9.1</b></p>
            <p className="hero-intro">Interfacto de control para Sung Shadow <strong>LVL 11</strong>. Seoul permanece bajo vigilancia.</p>
            <div className="hero-actions"><Button id="btnArise" onClick={handleArise} aria-pressed={arisen}><Sparkles size={15} /> {t.arise}</Button><span className="system-status"><i /> SYSTEM ONLINE</span></div>
          </div>
          <button className="sprite lys-sprite" onClick={() => setActiveForge("lys")} aria-label="Abrir LYS"><img src={lysImage} width={768} height={1024} alt="LYS 22, capitana de cinco divisiones" /><span><b>LYS // 22</b><small>TIERNA / CAPITANA</small></span></button>
          <button className="sprite kkamak-sprite" onClick={() => playSignal("/audio/kraw.mp3", 360)} aria-label="Escuchar a KKAMAK"><img src={kkamakImage} width={768} height={768} alt="KKAMAK, cuervo de 30 centímetros con ojo amarillo" /><span><b>KKAMAK // 30cm</b><small>500yr / MOTOR</small></span></button>
          <div className="hero-coordinates">37.5665° N<br />126.9780° E</div>
        </section>

        <section className="section nexus" aria-labelledby="nexus-title">
          <SectionHead code="NEXUS://500" eyebrow="INTERFACTO CENTRAL" title={t.nexus} />
          <div className="search-shell"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar distrito, SCP, módulo o unidad..." aria-label="Buscar en 500 unidades" /><Button variant="ghost" size="icon" onClick={() => setQuery("")} aria-label="Limpiar búsqueda"><X size={16} /></Button></div>
          <div className="result-meta"><span>{filteredUnits.length.toString().padStart(3, "0")} / 500 SIGNALS</span><span>FILTER // {query ? "ACTIVE" : "ALL"}</span></div>
          <div id="megaItems" className="unit-strip">
            {filteredUnits.slice(0, 8).map((unit) => <article key={unit.id}><small>UNIT {String(unit.id).padStart(3, "0")}</small><b>{unit.name}</b><span>{unit.type}</span><i className={unit.status === "ONLINE" ? "online" : "watch"}>{unit.status}</i></article>)}
          </div>
        </section>

        <section className="section" id="stats">
          <SectionHead code="SYS-STAT-011" eyebrow="MONARCH TELEMETRY" title="SYSTEM STATS" />
          <div className="stat-grid">{[["COMPILES", compileCount], ["LYS XP", "1,100"], ["SHADOWS", "500"], ["MEMORY", "847"], ["GATES", "06"]].map(([label, value], index) => <article key={label}><span>0{index + 1}</span><b>{value}</b><small>{label}</small><Activity size={16} /></article>)}</div>
        </section>

        <section className="section" id="missions">
          <SectionHead code="OPS://03 ACTIVE" eyebrow="ACTIVE OPERATIONS" title={t.missions} />
          <div className="mission-list">{[["S", "AWAKEN SEOUL CORE", 80], ["A", "FIVE DIVISIONS PROTOCOL", 40], ["B", "KKAMAK FLIGHT PATH", 10]].map(([rank, name, progress]) => <article key={String(name)}><span className="rank">{rank}-RANK</span><div><h3>{name}</h3><small>MONARCH AUTHORIZATION REQUIRED</small></div><div className="progress"><i style={{ width: `${progress}%` }} /></div><b>{progress}%</b></article>)}</div>
        </section>

        <section className="section" id="army">
          <SectionHead code="LEGION://03" eyebrow="SHADOW EXTRACTION REGISTRY" title="SHADOW ARMY" />
          <div className="army-grid">{army.map((fighter, index) => <article className="army-card" key={fighter.name} onMouseMove={(event) => { const rect = event.currentTarget.getBoundingClientRect(); event.currentTarget.style.setProperty("--rx", `${((event.clientY - rect.top) / rect.height - .5) * -8}deg`); event.currentTarget.style.setProperty("--ry", `${((event.clientX - rect.left) / rect.width - .5) * 8}deg`); }} onMouseLeave={(event) => { event.currentTarget.style.setProperty("--rx", "0deg"); event.currentTarget.style.setProperty("--ry", "0deg"); }}><div className={`army-crop crop-${index}`}><img src={armyImage} loading="lazy" width={1400} height={800} alt={`${fighter.name}, shadow army ${fighter.role}`} /></div><div className="army-data"><span>{fighter.rank}</span><h3>{fighter.name}</h3><p>{fighter.role}</p><strong>POWER {fighter.stat}</strong></div></article>)}</div>
        </section>

        <section className="section timeline-section">
          <SectionHead code="ARCHIVE://08" eyebrow="KERNEL EVOLUTION" title="TIMELINE LORE" />
          <div className="timeline">{["v1 / SEED", "v2 / VEIL", "v3 / ARCHK", "v4 / LYS", "v5 / KKAMAK", "v6 / GATES", "v7 / ARMY", "v8.2 / ECLIPSE"].map((version, index) => <article key={version}><span>0{index + 1}</span><i /><b>{version}</b><small>{2019 + index}</small></article>)}</div>
        </section>

        <section className="section criminal-sector">
          <div><p className="eyebrow">CLASSIFIED SEASON // RED PROTOCOL</p><h2>CRIMINALES <span>SOMBRA</span></h2><p>Una señal prohibida atraviesa el Distrito 7. Sus identidades permanecen cifradas.</p></div><div className="locked-seal"><LockKeyhole size={28} /><span>SEASON GATE</span><b>LOCKED</b><small>AUTH LVL 30 REQUIRED</small></div>
        </section>

        <section className="section" id="forge">
          <SectionHead code="ARCHK-30 // SAFE" eyebrow="DEVELOPMENT ENVIRONMENT" title="DEV FORGE" />
          <div className="forge">
            <div className="forge-tabs" role="tablist">{([{ id: "archk", label: "ARCHK" }, { id: "lys", label: "LYS CHAT" }, { id: "kkamak", label: "KKAMAK" }, { id: "rgb", label: "RGB LAB" }]).map((tab) => <Button key={tab.id} variant={activeForge === tab.id ? "default" : "ghost"} onClick={() => setActiveForge(tab.id)} aria-selected={activeForge === tab.id}>{tab.label}</Button>)}</div>
            {activeForge === "archk" && <div className="forge-body"><div className="editor-pane"><div className="pane-bar"><span>archk://world/seoul.archk</span><b>NO EVAL // SAFE</b></div><textarea id="archk-code" value={code} onChange={(event) => setCode(event.target.value)} spellCheck={false} aria-label="Código ARCHK" /><div className="compiler-row"><Button id="compileButton" onClick={() => { setCompileCount((count) => count + 1); setCompileMessage(parsed.message); }}><Cpu size={15} /> COMPILE</Button><output>{compileMessage}</output></div></div><div className="preview-pane"><div className="pane-bar"><span>WORLD PREVIEW</span><b>{parsed.entities.length} ENTITIES</b></div><canvas ref={canvasRef} width={520} height={300} aria-label="Vista previa animada ARCHK" /><div className="legend"><span>🌊 RIVER</span><span>🏔️ MOUNTAIN</span><span>🏙️ CITY</span></div></div></div>}
            {activeForge === "lys" && <div className="brain-panel"><div className="brain-status"><span>🧠 LYS BRAIN // DUAL CORE</span><b className={brainOnline ? "online" : "offline"}>{brainOnline ? "ONLINE BRAIN" : "OFFLINE BRAIN"}</b></div><div id="lysChat" className="chat-log">{chat.map((message, index) => <p key={`${message.by}-${index}`}><b>{message.by} //</b> {message.text}</p>)}</div><form onSubmit={handleChat}><input name="message" maxLength={240} placeholder="22 + 5, estado del sistema..." aria-label="Mensaje para LYS" /><Button type="submit">SEND</Button></form></div>}
            {activeForge === "kkamak" && <div className="motor-panel"><img src={kkamakImage} width={768} height={768} alt="KKAMAK motor" /><div><p className="eyebrow">🐦‍⬛ KKAMAK MOTOR</p><h3>YELLOW EYE SCANNER</h3><p>Cuervo real, 30cm. Adolescente de 500 años. Motor creado por Sung Shadow.</p><div className="readouts"><span>WING <b>ACTIVE</b></span><span>CORE <b>SHADOW</b></span><span>VISION <b>99.8%</b></span></div><Button onClick={() => playSignal("/audio/kraw.mp3", 360)}><Volume2 size={15} /> KRAW SIGNAL</Button></div></div>}
            {activeForge === "rgb" && <div className="rgb-lab"><p>GENERAL SYSTEM THEME</p><div>{themes.map((name) => <Button variant="ghost" key={name} className={`swatch ${name} ${theme === name ? "selected" : ""}`} onClick={() => { setTheme(name); safeStorage.set("theme", name); }} aria-label={`Tema ${name}`}><i /><span>{name}</span></Button>)}</div></div>}
          </div>
        </section>

        <section className="section" id="gates">
          <SectionHead code="GATES://06 NODES" eyebrow="DIMENSIONAL ACCESS CONTROL" title="SHADOW GATES" />
          <div className="gate-grid">{[["SEOUL PRIME", "S", false], ["GANGNAM VEIL", "A", false], ["HANGANG CURRENT", "B", false], ["MONARCH THRONE", "S+", false], ["RED MOON", "?", true], ["ABYSS ZERO", "?", true]].map(([name, rank, locked]) => <article key={String(name)} className={locked ? "locked" : ""}><span>{locked ? <LockKeyhole size={18} /> : <Shield size={18} />}</span><small>{rank}-RANK</small><h3>{name}</h3><Button variant={locked ? "danger" : "outline"} size="sm" onClick={() => setGateResult(locked ? `${name} // ACCESS DENIED` : `${name} // GATE OPEN`)}>{locked ? "LOCKED" : "ENTER"}<ChevronRight size={13} /></Button></article>)}</div><output id="gateResult" className="gate-result">{gateResult}</output>
        </section>

        <section className="section terminal-section">
          <SectionHead code="SHELL://SECURE" eyebrow="MONARCH COMMAND LINE" title="TERMINAL CONSOLE" />
          <div className="terminal"><div className="terminal-bar"><TerminalIcon size={14} /><span>root@sung-shadow:~</span><i>ENCRYPTED</i></div><div className="terminal-output">{terminalLines.map((line, index) => <p key={`${line}-${index}`}>{line}</p>)}</div><form onSubmit={runTerminal}><Command size={15} /><span>root@eclipse:~$</span><input name="command" autoComplete="off" aria-label="Terminal command" placeholder="type help" /></form></div>
        </section>

        <section className="section" id="wiki">
          <SectionHead code="847 INDEXED" eyebrow="ARCHK COMMAND DATABASE" title="ARCHK WIKI" />
          <div className="wiki-search"><Search size={15} /><input value={wikiQuery} onChange={(event) => setWikiQuery(event.target.value)} placeholder="Buscar comando, módulo o descripción..." aria-label="Buscar en la wiki" /><b>{filteredWiki.length} / 847</b></div>
          <div className="wiki-viewport" onScroll={(event) => setWikiScroll(event.currentTarget.scrollTop)}><table><thead><tr><th>#</th><th>COMMAND</th><th>SECTION</th><th>CODE</th><th>DESCRIPTION</th></tr></thead><tbody id="wikiBody"><tr aria-hidden="true"><td style={{ height: virtual.start * 42 }} colSpan={5} /></tr>{virtual.rows.map((row) => <tr key={row.id}><td>{String(row.id).padStart(3, "0")}</td><td>{row.command}</td><td>{row.section}</td><td>{row.emoji}</td><td>{row.description}</td></tr>)}<tr aria-hidden="true"><td style={{ height: Math.max(0, virtual.totalHeight - (virtual.start + virtual.rows.length) * 42) }} colSpan={5} /></tr></tbody></table></div>
        </section>
        <section className="section">
          <SectionHead code="ARCADE://04" eyebrow="OFFICIAL GAMES // EARN XP" title="SHADOW ARCADE" />
          <div className="grid-3">{[["⚔️", "SHADOW CLICKER", "Extract shadows, chain x10 combos."], ["🔮", "RUNE MEMORY", "Match the ARCHK emoji runes."], ["🐦‍⬛", "KKAMAK FLIGHT", "Fly the raven through the gates."], ["🚪", "GATE RUNNER", "Dodge monsters inside the dungeon."]].map(([e, n, d]) => <Link key={n} to="/games" className="panel hover-scale" style={{ textDecoration: "none" }}><div style={{ fontSize: 40 }}>{e}</div><h3>{n}</h3><p>{d}</p></Link>)}</div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}

function SectionHead({ code, eyebrow, title }: { code: string; eyebrow: string; title: string }) {
  return <div className="section-head"><div><p className="eyebrow">{eyebrow}</p><h2 id={title.includes("NEXUS") ? "nexus-title" : undefined}>{title}</h2></div><span>{code}</span></div>;
}