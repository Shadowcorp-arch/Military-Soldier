import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Switch } from "@/components/ui/switch";
import { PageHero, SiteShell } from "@/components/eclipse/SiteShell";
import { supabase } from "@/integrations/supabase/client";
import { isMuted, setMuted, sfx } from "@/js/core/sfx";
import { useAuth, useProfile, XP_PER_LEVEL } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [
    { title: "Hunter Dashboard — ECLIPSEOS" },
    { name: "description", content: "Your hunter profile, level, XP, game records, events calendar and settings." },
    { property: "og:title", content: "Hunter Dashboard — ECLIPSEOS" },
    { property: "og:description", content: "Track your level, XP and shadow records." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Dashboard,
});

const today = new Date();
const d = (offset: number) => new Date(today.getFullYear(), today.getMonth(), today.getDate() + offset);
const EVENTS = [
  { date: d(1), title: "🚪 Red Moon Gate opens", tag: "S-RANK" },
  { date: d(3), title: "⚔️ Shadow Army tournament", tag: "PVP" },
  { date: d(6), title: "🐦‍⬛ KKAMAK flight race", tag: "EVENT" },
  { date: d(10), title: "🌑 Criminales Sombra season teaser", tag: "LORE" },
  { date: d(14), title: "👑 Monarch double XP weekend", tag: "XP x2" },
];

function Dashboard() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [day, setDay] = useState<Date | undefined>(today);
  const [muted, setMute] = useState(isMuted());

  const { data: scores } = useQuery({
    queryKey: ["scores", user?.id], enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("game_scores").select("game, score, created_at").order("score", { ascending: false }).limit(100);
      if (error) throw error; return data;
    },
  });
  const best = ["clicker", "memory", "flight", "runner"].map((g) => ({ g, s: scores?.find((x) => x.game === g)?.score ?? 0, runs: scores?.filter((x) => x.game === g).length ?? 0 }));

  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!user) return;
    const f = new FormData(e.currentTarget);
    const hunter_name = String(f.get("hunter") ?? "").trim().slice(0, 30) || "Hunter";
    const avatar = String(f.get("avatar") ?? "").trim();
    const avatar_url = /^https:\/\//.test(avatar) ? avatar.slice(0, 500) : null;
    const { error } = await supabase.from("profiles").update({ hunter_name, avatar_url, updated_at: new Date().toISOString() }).eq("id", user.id);
    if (error) { toast.error("Could not save profile"); return; }
    sfx.success(); toast.success("Profile saved"); void qc.invalidateQueries({ queryKey: ["profile"] });
  }

  async function signOut() {
    await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); void navigate({ to: "/auth", replace: true });
  }

  const xp = profile?.xp ?? 0; const pct = ((xp % XP_PER_LEVEL) / XP_PER_LEVEL) * 100;
  const name = profile?.hunter_name ?? "Hunter";
  const dayEvents = EVENTS.filter((ev) => day && ev.date.toDateString() === day.toDateString());

  return (
    <SiteShell>
      <PageHero eyebrow="MONARCH TELEMETRY // HUNTER PROFILE" title={`WELCOME, ${name.toUpperCase()}`} />
      <div className="grid-3">
        <div className="panel grid gap-4">
          <div className="flex items-center gap-4">
            {profile?.avatar_url ? <img src={profile.avatar_url} alt={name} className="avatar-lg" width={84} height={84} /> : <div className="avatar-lg">{name[0]?.toUpperCase()}</div>}
            <div><h2>{name}</h2><p>LEVEL <b className="text-primary">{profile?.level ?? 1}</b> · {xp} XP</p></div>
          </div>
          <div className="xp-bar"><i style={{ width: `${pct}%` }} /></div>
          <p className="text-xs">{XP_PER_LEVEL - (xp % XP_PER_LEVEL)} XP to next level</p>
          <Link to="/games"><Button className="w-full">PLAY & EARN XP</Button></Link>
        </div>
        <div className="panel">
          <h2>GAME RECORDS</h2>
          {best.map((b) => <div className="kv" key={b.g}><span>{b.g.toUpperCase()}</span><span>BEST <b>{b.s}</b> · {b.runs} runs</span></div>)}
        </div>
        <div className="panel">
          <h2>SETTINGS</h2>
          <div className="kv"><span>SOUND EFFECTS</span><Switch checked={!muted} onCheckedChange={(on) => { setMuted(!on); setMute(!on); if (on) sfx.success(); }} /></div>
          <div className="kv"><span>RGB MODE</span><b>{(profile?.rgb_mode ?? "off").toUpperCase()}</b></div>
          <div className="kv"><span>EMAIL</span><span className="truncate max-w-40">{user?.email}</span></div>
          <Button variant="danger" className="mt-4 w-full" onClick={signOut}>SIGN OUT</Button>
        </div>
      </div>
      <div className="grid-2">
        <form className="panel grid gap-3" onSubmit={save} key={profile?.id}>
          <h2>EDIT PROFILE</h2>
          <label className="field">HUNTER NAME<input name="hunter" defaultValue={name} maxLength={30} /></label>
          <label className="field">AVATAR IMAGE URL (https)<input name="avatar" defaultValue={profile?.avatar_url ?? ""} placeholder="https://..." /></label>
          <Button type="submit">SAVE PROFILE</Button>
        </form>
        <div className="panel">
          <h2>EVENTS CALENDAR</h2>
          <div className="flex flex-wrap gap-4">
            <Calendar mode="single" selected={day} onSelect={setDay} modifiers={{ event: EVENTS.map((e) => e.date) }} modifiersClassNames={{ event: "text-primary font-bold underline" }} />
            <div className="flex-1 min-w-48">
              {(dayEvents.length ? dayEvents : EVENTS).map((ev) => <div className="event-row" key={ev.title}><time>{ev.date.toLocaleDateString(undefined, { month: "short", day: "numeric" })}</time><span className="flex-1 text-sm">{ev.title}</span><small className="text-primary text-xs">{ev.tag}</small></div>)}
            </div>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
