import { useEffect, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { sfx } from "@/js/core/sfx";

type GameProps = { onFinish: (score: number) => void };

function cssVar(el: Element, name: string, fallback: string) {
  return getComputedStyle(el).getPropertyValue(name).trim() || fallback;
}

/* ⚔️ SHADOW CLICKER — 20 second extraction round */
export function ShadowClicker({ onFinish }: GameProps) {
  const [time, setTime] = useState(0);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(1);
  const last = useRef(0);
  useEffect(() => {
    if (time <= 0) return;
    const id = window.setTimeout(() => { setTime((t) => t - 1); if (time === 1) { sfx.levelUp(); onFinish(score); } }, 1000);
    return () => clearTimeout(id);
  }, [time, score, onFinish]);
  function extract() {
    const now = performance.now();
    const next = now - last.current < 280 ? Math.min(combo + 1, 10) : 1;
    last.current = now; setCombo(next); setScore((s) => s + next); sfx.click();
  }
  return (
    <div className="game-stage">
      <div className="game-hud"><span>TIME <b>{time}s</b></span><span>SHADOWS <b>{score}</b></span><span>COMBO <b>x{combo}</b></span></div>
      <button className="orb" onClick={extract} disabled={time <= 0}>👤</button>
      {time <= 0 && <Button onClick={() => { setScore(0); setCombo(1); setTime(20); sfx.whoosh(); }}>ARISE · START</Button>}
      <p className="text-xs text-muted-foreground">Click fast to chain combos up to x10.</p>
    </div>
  );
}

/* 🔮 RUNE MEMORY — match ARCHK emoji pairs */
const RUNES = ["🌊", "🏔️", "🏙️", "⚔️", "👤", "🐦‍⬛", "🌑", "👑"];
const shuffle = () => [...RUNES, ...RUNES].map((r) => ({ r, k: Math.random() })).sort((a, b) => a.k - b.k).map((x, i) => ({ id: i, rune: x.r, up: false, done: false }));
export function RuneMemory({ onFinish }: GameProps) {
  const [cards, setCards] = useState(shuffle);
  const [picked, setPicked] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  useEffect(() => { setCards(shuffle()); }, []);
  function flip(i: number) {
    if (picked.length === 2 || cards[i]?.up || cards[i]?.done) return;
    sfx.click();
    const next = cards.map((c, idx) => (idx === i ? { ...c, up: true } : c));
    const sel = [...picked, i];
    setCards(next); setPicked(sel);
    if (sel.length === 2) {
      setMoves((m) => m + 1);
      const a = sel[0]!, b = sel[1]!;
      window.setTimeout(() => {
        setCards((cs) => {
          const match = cs[a]?.rune === cs[b]?.rune;
          match ? sfx.coin() : sfx.hit();
          const upd = cs.map((c, idx) => (idx === a || idx === b ? { ...c, up: match, done: match } : c));
          if (upd.every((c) => c.done)) { sfx.levelUp(); onFinish(Math.max(100, 1000 - (moves + 1) * 25)); }
          return upd;
        });
        setPicked([]);
      }, 650);
    }
  }
  return (
    <div className="game-stage">
      <div className="game-hud"><span>MOVES <b>{moves}</b></span><span>PAIRS <b>{cards.filter((c) => c.done).length / 2}/8</b></span></div>
      <div className="memory-grid">{cards.map((c, i) => <button key={c.id} className={`memory-card ${c.up ? "up" : ""} ${c.done ? "done" : ""}`} onClick={() => flip(i)} aria-label="Rune card"><span>{c.up ? c.rune : "◆"}</span></button>)}</div>
      <Button variant="outline" onClick={() => { setCards(shuffle()); setMoves(0); setPicked([]); }}>RESHUFFLE</Button>
    </div>
  );
}

/* 🐦‍⬛ KKAMAK FLIGHT — fly through the gates */
export function KkamakFlight({ onFinish }: GameProps) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [score, setScore] = useState(0);
  const flap = useRef<() => void>(() => {});
  useEffect(() => {
    const canvas = ref.current; if (!canvas || !running) return;
    const ctx = canvas.getContext("2d")!; const W = 600, H = 400;
    const primary = cssVar(canvas, "--primary", "#2de"), accent = cssVar(canvas, "--accent", "#e33");
    let y = H / 2, vy = 0, frame = 0, pts = 0, raf = 0, alive = true;
    const pipes: { x: number; gap: number; passed: boolean }[] = [];
    flap.current = () => { vy = -6.2; sfx.flap(); };
    const loop = () => {
      frame++; vy += 0.32; y += vy;
      if (frame % 95 === 0) pipes.push({ x: W, gap: 80 + Math.random() * (H - 240), passed: false });
      ctx.fillStyle = "rgba(5,8,20,.9)"; ctx.fillRect(0, 0, W, H);
      for (let i = 0; i < 40; i++) { ctx.fillStyle = "rgba(255,255,255,.15)"; ctx.fillRect((i * 97 - frame * 0.5) % W + W * (i * 97 - frame * 0.5 < 0 ? 1 : 0), (i * 53) % H, 2, 2); }
      pipes.forEach((p) => {
        p.x -= 3; ctx.fillStyle = accent; ctx.shadowColor = accent; ctx.shadowBlur = 12;
        ctx.fillRect(p.x, 0, 46, p.gap); ctx.fillRect(p.x, p.gap + 140, 46, H);
        ctx.shadowBlur = 0;
        if (!p.passed && p.x + 46 < 120) { p.passed = true; pts++; setScore(pts); sfx.coin(); }
        if (120 + 14 > p.x && 120 - 14 < p.x + 46 && (y - 12 < p.gap || y + 12 > p.gap + 140)) alive = false;
      });
      ctx.font = "28px serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("🐦‍⬛", 120, y);
      ctx.fillStyle = primary; ctx.beginPath(); ctx.arc(128, y - 4, 2.5, 0, 7); ctx.fill();
      if (y > H || y < 0) alive = false;
      if (!alive) { sfx.hit(); setRunning(false); onFinish(pts * 40); return; }
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [running, onFinish]);
  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.code === "Space" && running) { e.preventDefault(); flap.current(); } };
    window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key);
  }, [running]);
  return (
    <div className="game-stage">
      <div className="game-hud"><span>GATES <b>{score}</b></span><span>SPACE / TAP = FLAP</span></div>
      <canvas ref={ref} width={600} height={400} onPointerDown={() => running && flap.current()} />
      {!running && <Button onClick={() => { setScore(0); setRunning(true); }}>LAUNCH KKAMAK</Button>}
    </div>
  );
}

/* 🚪 GATE DUNGEON RUNNER — dodge falling monsters */
export function GateRunner({ onFinish }: GameProps) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [score, setScore] = useState(0);
  useEffect(() => {
    const canvas = ref.current; if (!canvas || !running) return;
    const ctx = canvas.getContext("2d")!; const W = 600, H = 400;
    const primary = cssVar(canvas, "--primary", "#2de");
    let x = W / 2, frame = 0, raf = 0, pts = 0; const keys = new Map<string, boolean>();
    const foes: { x: number; y: number; v: number; e: string }[] = [];
    const kd = (e: KeyboardEvent) => { keys.set(e.key, true); }; const ku = (e: KeyboardEvent) => { keys.set(e.key, false); };
    const pm = (e: PointerEvent) => { const r = canvas.getBoundingClientRect(); x = ((e.clientX - r.left) / r.width) * W; };
    window.addEventListener("keydown", kd); window.addEventListener("keyup", ku); canvas.addEventListener("pointermove", pm);
    const loop = () => {
      frame++;
      if (keys.get("ArrowLeft") || keys.get("a")) x -= 6; if (keys.get("ArrowRight") || keys.get("d")) x += 6; x = Math.max(16, Math.min(W - 16, x));
      if (frame % Math.max(10, 32 - Math.floor(frame / 300)) === 0) foes.push({ x: Math.random() * W, y: -20, v: 2.5 + Math.random() * 2 + frame / 1200, e: ["👹", "🐺", "💀", "🕷️"][Math.floor(Math.random() * 4)] ?? "👹" });
      if (frame % 10 === 0) { pts++; setScore(pts); }
      ctx.fillStyle = "rgba(10,4,16,.85)"; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(255,255,255,.06)"; for (let gy = (frame * 2) % 40; gy < H; gy += 40) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
      ctx.font = "26px serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      let hit = false;
      foes.forEach((f) => { f.y += f.v; ctx.fillText(f.e, f.x, f.y); if (Math.hypot(f.x - x, f.y - (H - 36)) < 26) hit = true; });
      ctx.shadowColor = primary; ctx.shadowBlur = 18; ctx.fillText("👤", x, H - 36); ctx.shadowBlur = 0;
      if (hit) { sfx.hit(); setRunning(false); onFinish(pts * 5); return; }
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); canvas.removeEventListener("pointermove", pm); };
  }, [running, onFinish]);
  return (
    <div className="game-stage">
      <div className="game-hud"><span>DISTANCE <b>{score}</b></span><span>← → / MOUSE / TOUCH</span></div>
      <canvas ref={ref} width={600} height={400} />
      {!running && <Button onClick={() => { setScore(0); setRunning(true); sfx.whoosh(); }}>ENTER GATE</Button>}
    </div>
  );
}
