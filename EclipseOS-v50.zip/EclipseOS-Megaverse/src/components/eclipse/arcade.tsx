import { useEffect, useRef, useState } from "react";

import { sfx } from "@/js/core/sfx";

type GameProps = { onFinish: (score: number) => void };

/* ⚙️ Shared engine 1: FIELD — move along the bottom, catch good emojis, dodge hazards. */
type FieldCfg = { player: string; good: string[]; bad: string[]; speed: number; spawn: number; time: number };
function makeField(cfg: FieldCfg) {
  return function FieldGame({ onFinish }: GameProps) {
    const ref = useRef<HTMLCanvasElement>(null);
    const [hud, setHud] = useState({ score: 0, lives: 3, t: cfg.time });
    const [running, setRunning] = useState(false);
    useEffect(() => {
      if (!running) return;
      const c = ref.current!; const ctx = c.getContext("2d")!;
      const W = c.width, H = c.height; let px = W / 2, score = 0, lives = 3, raf = 0, last = performance.now(), acc = 0, left = cfg.time;
      const keys = new Set<string>();
      const items: { x: number; y: number; e: string; good: boolean; v: number }[] = [];
      const move = (cx: number) => { const r = c.getBoundingClientRect(); px = ((cx - r.left) / r.width) * W; };
      const pm = (e: PointerEvent) => move(e.clientX);
      const kd = (e: KeyboardEvent) => keys.add(e.key); const ku = (e: KeyboardEvent) => keys.delete(e.key);
      c.addEventListener("pointermove", pm); window.addEventListener("keydown", kd); window.addEventListener("keyup", ku);
      const end = () => { cancelAnimationFrame(raf); setRunning(false); sfx.levelUp(); onFinish(score); };
      const loop = (now: number) => {
        const dt = Math.min(0.05, (now - last) / 1000); last = now; left -= dt; acc += dt;
        if (keys.has("ArrowLeft") || keys.has("a")) px -= 420 * dt;
        if (keys.has("ArrowRight") || keys.has("d")) px += 420 * dt;
        px = Math.max(20, Math.min(W - 20, px));
        if (acc > cfg.spawn) { acc = 0; const good = Math.random() < 0.6; const pool = good ? cfg.good : cfg.bad;
          items.push({ x: 20 + Math.random() * (W - 40), y: -20, e: pool[Math.floor(Math.random() * pool.length)]!, good, v: cfg.speed * (0.7 + Math.random() * 0.6) * (1 + (cfg.time - left) / cfg.time) }); }
        ctx.fillStyle = "rgba(5,8,20,.35)"; ctx.fillRect(0, 0, W, H);
        ctx.font = "28px serif"; ctx.textAlign = "center";
        for (let i = items.length - 1; i >= 0; i--) { const it = items[i]!; it.y += it.v * dt; ctx.fillText(it.e, it.x, it.y);
          if (it.y > H - 50 && it.y < H - 10 && Math.abs(it.x - px) < 30) { items.splice(i, 1);
            if (it.good) { score += 10; sfx.coin(); } else { lives--; sfx.hit(); } }
          else if (it.y > H + 20) items.splice(i, 1); }
        ctx.font = "34px serif"; ctx.fillText(cfg.player, px, H - 18);
        setHud({ score, lives, t: Math.ceil(left) });
        if (lives <= 0 || left <= 0) return end();
        raf = requestAnimationFrame(loop);
      };
      raf = requestAnimationFrame(loop);
      return () => { cancelAnimationFrame(raf); c.removeEventListener("pointermove", pm); window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); };
    }, [running, onFinish]);
    return (
      <div className="game-stage">
        <div className="game-hud"><span>SCORE <b>{hud.score}</b></span><span>LIVES <b>{"❤".repeat(Math.max(0, hud.lives))}</b></span><span>TIME <b>{hud.t}s</b></span></div>
        <canvas ref={ref} width={600} height={400} />
        <p className="arc-hint">Catch {cfg.good.join(" ")} · avoid {cfg.bad.join(" ")} · mouse/touch or ←/→</p>
        {!running && <button className="arc-btn" onClick={() => { sfx.boot(); setHud({ score: 0, lives: 3, t: cfg.time }); setRunning(true); }}>▶ START</button>}
      </div>
    );
  };
}

/* ⚙️ Shared engine 2: TAP — strike targets before they fade. */
type TapCfg = { target: string; decoy: string; life: number; time: number };
function makeTap(cfg: TapCfg) {
  return function TapGame({ onFinish }: GameProps) {
    const [cells, setCells] = useState<(string | null)[]>(Array(16).fill(null));
    const [score, setScore] = useState(0); const [t, setT] = useState(cfg.time); const [run, setRun] = useState(false);
    const scoreRef = useRef(0);
    useEffect(() => {
      if (!run) return;
      const spawn = window.setInterval(() => {
        const i = Math.floor(Math.random() * 16); const e = Math.random() < 0.75 ? cfg.target : cfg.decoy;
        setCells((c) => c.map((v, j) => (j === i ? e : v)));
        window.setTimeout(() => setCells((c) => c.map((v, j) => (j === i && v === e ? null : v))), cfg.life);
      }, Math.max(250, cfg.life / 2));
      const tick = window.setInterval(() => setT((x) => x - 1), 1000);
      return () => { window.clearInterval(spawn); window.clearInterval(tick); };
    }, [run]);
    useEffect(() => { if (run && t <= 0) { setRun(false); sfx.levelUp(); onFinish(scoreRef.current); } }, [t, run, onFinish]);
    const hit = (i: number) => { const v = cells[i]; if (!run || !v) return;
      const d = v === cfg.target ? 15 : -20; scoreRef.current = Math.max(0, scoreRef.current + d); setScore(scoreRef.current);
      d > 0 ? sfx.shoot() : sfx.hit(); setCells((c) => c.map((x, j) => (j === i ? null : x))); };
    return (
      <div className="game-stage">
        <div className="game-hud"><span>SCORE <b>{score}</b></span><span>TIME <b>{t}s</b></span></div>
        <div className="arc-grid">{cells.map((v, i) => <button key={i} className={v ? "on" : ""} onPointerDown={() => hit(i)}>{v}</button>)}</div>
        <p className="arc-hint">Strike {cfg.target} · never {cfg.decoy}</p>
        {!run && <button className="arc-btn" onClick={() => { sfx.boot(); scoreRef.current = 0; setScore(0); setT(cfg.time); setCells(Array(16).fill(null)); setRun(true); }}>▶ START</button>}
      </div>
    );
  };
}

/* ⚙️ Shared engine 3: SEQUENCE — repeat a growing emoji sequence. */
function makeSeq(symbols: string[]) {
  return function SeqGame({ onFinish }: GameProps) {
    const [seq, setSeq] = useState<number[]>([]); const [step, setStep] = useState(0);
    const [flash, setFlash] = useState<number | null>(null); const [busy, setBusy] = useState(false); const [over, setOver] = useState(true);
    const play = (s: number[]) => { setBusy(true); s.forEach((v, i) => { window.setTimeout(() => { setFlash(v); sfx.type(); }, i * 600); window.setTimeout(() => setFlash(null), i * 600 + 400); });
      window.setTimeout(() => setBusy(false), s.length * 600); };
    const next = (s: number[]) => { const n = [...s, Math.floor(Math.random() * symbols.length)]; setSeq(n); setStep(0); play(n); };
    const press = (i: number) => { if (busy || over) return; sfx.click();
      if (seq[step] !== i) { sfx.hit(); setOver(true); onFinish((seq.length - 1) * 25); return; }
      if (step + 1 === seq.length) { sfx.coin(); window.setTimeout(() => next(seq), 500); } else setStep(step + 1); };
    return (
      <div className="game-stage">
        <div className="game-hud"><span>ROUND <b>{seq.length}</b></span></div>
        <div className="arc-seq">{symbols.map((s, i) => <button key={i} className={flash === i ? "on" : ""} onClick={() => press(i)}>{s}</button>)}</div>
        <p className="arc-hint">Watch the pattern, then repeat it.</p>
        {over && <button className="arc-btn" onClick={() => { sfx.boot(); setOver(false); next([]); }}>▶ START</button>}
      </div>
    );
  };
}

export const ARCADE = [
  { id: "meteor", name: "☄️ METEOR DODGE", family: "Arcade", Comp: makeField({ player: "🛸", good: ["💎"], bad: ["☄️"], speed: 180, spawn: 0.45, time: 45 }) },
  { id: "ramen", name: "🍜 SEOUL RAMEN RUSH", family: "Simulación", Comp: makeField({ player: "🥢", good: ["🍜", "🥟"], bad: ["🌶️"], speed: 150, spawn: 0.5, time: 40 }) },
  { id: "mana", name: "🔷 MANA HARVEST", family: "Arcade", Comp: makeField({ player: "🧙", good: ["🔷", "✨"], bad: ["💀"], speed: 170, spawn: 0.4, time: 45 }) },
  { id: "raven", name: "🐦‍⬛ RAVEN FEAST", family: "Arcade", Comp: makeField({ player: "🐦‍⬛", good: ["🌽", "🍒"], bad: ["⚡"], speed: 200, spawn: 0.4, time: 40 }) },
  { id: "storm", name: "🌩️ STORM SURVIVOR", family: "Acción", Comp: makeField({ player: "🏃", good: ["☂️"], bad: ["⚡", "🌩️"], speed: 240, spawn: 0.33, time: 50 }) },
  { id: "aurora", name: "🌌 AURORA CATCHER", family: "Simulación", Comp: makeField({ player: "🧺", good: ["⭐", "🌟"], bad: ["🌑"], speed: 140, spawn: 0.45, time: 45 }) },
  { id: "neon", name: "🏙️ NEON COURIER", family: "Acción", Comp: makeField({ player: "🛵", good: ["📦"], bad: ["🚧", "🚓"], speed: 260, spawn: 0.35, time: 45 }) },
  { id: "abyss", name: "🌊 ABYSS DIVER", family: "Simulación", Comp: makeField({ player: "🤿", good: ["🐚", "🦪"], bad: ["🦈"], speed: 160, spawn: 0.45, time: 50 }) },
  { id: "hunt", name: "👹 GATE HUNT", family: "Acción", Comp: makeTap({ target: "👹", decoy: "👤", life: 1100, time: 30 }) },
  { id: "igris", name: "⚔️ IGRIS DUEL", family: "Acción", Comp: makeTap({ target: "🗡️", decoy: "🛡️", life: 900, time: 30 }) },
  { id: "beru", name: "🐜 BERU SWARM", family: "Estrategia", Comp: makeTap({ target: "🐜", decoy: "🐝", life: 1000, time: 35 }) },
  { id: "ghost", name: "👻 GHOST PROTOCOL", family: "Estrategia", Comp: makeTap({ target: "👻", decoy: "🧍", life: 800, time: 30 }) },
  { id: "crimson", name: "🩸 CRIMSON SNIPER", family: "Acción", Comp: makeTap({ target: "🎯", decoy: "🕊️", life: 700, time: 30 }) },
  { id: "bug", name: "🐛 CODE DEBUGGER", family: "Puzzle", Comp: makeTap({ target: "🐛", decoy: "✅", life: 1000, time: 35 }) },
  { id: "runes", name: "🔮 RUNE ORACLE", family: "Puzzle", Comp: makeSeq(["🔥", "💧", "🌿", "⚡"]) },
  { id: "archk", name: "🧬 ARCHK PATTERN", family: "Puzzle", Comp: makeSeq(["🌊", "🏔️", "🏙️", "⚔️", "👤"]) },
  { id: "pillars", name: "🏯 FOUR PILLARS", family: "Puzzle", Comp: makeSeq(["身", "心", "衣", "魂"]) },
  { id: "dj", name: "🎧 HONGDAE DJ", family: "Simulación", Comp: makeSeq(["🥁", "🎹", "🎸", "🎺", "🎻", "🎷"]) },
  { id: "army", name: "🛡️ ARMY COMMANDER", family: "Estrategia", Comp: makeSeq(["🗡️", "🛡️", "🏹", "🐜", "🐻", "🐉"]) },
  { id: "weather", name: "🌦️ WEATHER MAGE", family: "Estrategia", Comp: makeSeq(["☀️", "🌧️", "❄️", "🌫️", "🌩️", "🌌"]) },
];
