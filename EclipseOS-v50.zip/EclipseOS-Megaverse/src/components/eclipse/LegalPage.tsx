import { PageHero, SiteShell } from "./SiteShell";

export function LegalPage({ title, updated, sections }: { title: string; updated: string; sections: [string, string][] }) {
  return (
    <SiteShell>
      <PageHero eyebrow={`LEGAL // LAST UPDATED ${updated}`} title={title} />
      <article className="panel legal">
        {sections.map(([h, p]) => <section key={h}><h2>{h}</h2><p>{p}</p></section>)}
      </article>
    </SiteShell>
  );
}
