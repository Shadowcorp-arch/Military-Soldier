import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import logo from "@/assets/eclipse-logo.png";
import { SOCIALS } from "@/components/eclipse/BrandIcons";
import { supabase } from "@/integrations/supabase/client";
import { safeStorage } from "@/js/core/security";
import { sfx } from "@/js/core/sfx";
import { useAuth, useProfile } from "@/lib/auth";
import { useOnline } from "@/lib/presence";

/** 🎭 Hunter avatar: emoji + hue ring + optional frame */
export function HunterAvatar({ emoji = "👤", hue = "190", frame = "none", size = 40, src }: { emoji?: string | undefined; hue?: string | undefined; frame?: string | undefined; size?: number; src?: string | null | undefined }) {
  return (
    <span className={`hunter-avatar frame-${frame}`} style={{ width: size, height: size, fontSize: size * 0.55, ["--av-h" as string]: hue }}>
      {src ? <img src={src} alt="" width={size} height={size} /> : emoji}
    </span>
  );
}

export function AccountButton() {
  const { user, ready } = useAuth();
  const { data: profile } = useProfile();
  if (!ready) return <span className="account-btn ghost">···</span>;
  if (!user) return <Link to="/auth" className="account-btn" onClick={sfx.click}>SIGN IN</Link>;
  const name = profile?.hunter_name ?? "Hunter";
  return (
    <Link to="/dashboard" className="account-btn" onClick={sfx.click}>
      <HunterAvatar emoji={profile?.avatar_emoji} hue={profile?.avatar_color} frame={profile?.avatar_frame} src={profile?.avatar_url} size={24} />
      <span>{name}</span><small>LV {profile?.level ?? 1}</small><small className="eclip-chip">◈ {profile?.eclip ?? 0}</small>
    </Link>
  );
}

export function OnlineBadge() {
  const online = useOnline();
  return <span className="online-badge" title="Hunters online now"><i />{Math.max(1, online.length)} ONLINE</span>;
}

export function SiteLogo() {
  return <Link to="/" className="brand"><img src={logo} width={30} height={30} alt="ECLIPSEOS logo" className="brand-logo" /><span>ECLIPSE<strong>OS</strong></span><small>v10 SOVEREIGN</small></Link>;
}

const NAV = [
  { to: "/", label: "HOME" }, { to: "/games", label: "GAMES" }, { to: "/dashboard", label: "DASHBOARD" },
  { to: "/pricing", label: "PLANS" }, { to: "/support", label: "SUPPORT" },
] as const;

function AnnouncementBar() {
  const { data } = useQuery({
    queryKey: ["announcements"],
    queryFn: async () => (await supabase.from("announcements").select("id, message").order("created_at", { ascending: false }).limit(1)).data ?? [],
    staleTime: 60_000,
  });
  const [hidden, setHidden] = useState(false);
  const a = data?.[0];
  if (!a || hidden) return null;
  return <div className="announce-bar"><span>📢 {a.message}</span><button onClick={() => setHidden(true)} aria-label="Dismiss">✕</button></div>;
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-grid">
        <div><SiteLogo /><p>Shadow OS for the Seoul Megaverse. Create worlds, stories, games and apps. Sung Shadow // LVL 11.</p>
          <div className="social-row">{SOCIALS.map(({ name, Icon }) => <span key={name} title={`${name} — coming soon`} className="social-dot"><Icon size={18} /></span>)}</div>
        </div>
        <div><b>PLAY</b><Link to="/games">Games</Link><Link to="/dashboard">Dashboard</Link></div>
        <div><b>HELP</b><Link to="/support">Docs & Support</Link></div>
        <div><b>LEGAL</b><Link to="/terms">Terms of Service</Link><Link to="/privacy">Privacy Policy</Link><Link to="/copyright">Copyright</Link><Link to="/support">Support</Link><Link to="/pricing">Plans</Link></div>
      </div>
      <p className="copyright">© 2026 ECLIPSEOS · Shadow Corp Company · Sung Shadow. All rights reserved. · SYSTEM INTEGRITY 99.91%</p>
    </footer>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState("shadow");
  useEffect(() => setTheme(safeStorage.get("theme", "shadow")), []);
  return (
    <div className={`eclipse-app theme-${theme} site-page`}>
      <div className="scanline" aria-hidden="true" />
      <AnnouncementBar />
      <header className="command-header">
        <SiteLogo />
        <nav aria-label="Main">{NAV.map((n) => <Link key={n.to} to={n.to} activeOptions={{ exact: true }} activeProps={{ className: "active" }} onMouseEnter={sfx.hover}>{n.label}</Link>)}</nav>
        <div className="header-tools"><OnlineBadge /><AccountButton /></div>
      </header>
      <main className="site-main">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({ eyebrow, title, text, image }: { eyebrow: string; title: string; text?: string; image?: string }) {
  return (
    <div className={`page-hero ${image ? "with-image" : ""}`}>
      {image && <img src={image} alt="" width={1536} height={864} className="page-hero-img" />}
      <p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{text && <p>{text}</p>}
    </div>
  );
}
