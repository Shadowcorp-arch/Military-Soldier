import { useEffect, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { sfx } from "@/js/core/sfx";

/* 🔫 SHADOW SWAT: EXTRACTION — top-down tactical infiltration shooter */
type Props = { onFinish: (score: number) => void };
type Rect = { x: number; y: number; w: number; h: number };
type Guard = { x: number; y: number; a: number; hp: number; path: [number, number][]; wp: number; alert: number; cd: number };
type Bullet = { x: number; y: number; vx: number; vy: number; enemy: boolean; life: number };

const W = 800, H = 500;
const WALLS: Rect[] = [
  { x: 0, y: 0, w: W, h: 10 }, { x: 0, y: H - 10, w: W, h: 10 }, { x: 0, y: 0, w: 10, h: H }, { x: W - 10, y: 0, w: 10, h: H },
  { x: 180, y: 10, w: 16, h: 170 }, { x: 180, y: 260, w: 16, h: 150 }, { x: 330, y: 120, w: 170, h: 16 }, { x: 330, y: 136, w: 16, h: 120 },
  { x: 420, y: 330, w: 16, h: 160 }, { x: 560, y: 60, w: 16, h: 200 }, { x: 576, y: 244, w: 120, h: 16 }, { x: 260, y: 380, w: 100, h: 16 },
  { x: 640, y: 360, w: 16, h: 130 },
];
const LOADOUTS = {
  smg: { name: "MP5-SD (suppressed)", rate: 110, dmg: 34, spread: 0.08, mag: 30, noise: 60 },
  rifle: { name: "M4 Rifle", rate: 170, dmg: 55, spread: 0.03, mag: 24, noise: 220 },
  shotgun: { name: "M870 Breacher", rate: 650, dmg: 40, spread: 0.25, mag: 6, noise: 260 },
} as const;
const DIFF = { recruit: { guards: 5, acc: 0.25, hp: 100 }, operator: { guards: 7, acc: 0.15, hp: 80 }, elite: { guards: 9, acc: 0.08, hp: 60 } } as const;
type Loadout = keyof typeof LOADOUTS; type Difficulty = keyof typeof DIFF;

const hitWall = (x: number, y: number, r = 0) => WALLS.some((w) => x + r > w.x && x - r < w.x + w.w && y + r > w.y && y - r < w.y + w.h);
function sight(ax: number, ay: number, bx: number, by: number) {
  const d = Math.hypot(bx - ax, by - ay); const steps = Math.ceil(d / 8);
  for (let i = 1; i < steps; i++) if (hitWall(ax + ((bx - ax) * i) / steps, ay + ((by - ay) * i) / steps)) return false;
  return true;
}

export function SwatExtraction({ onFinish }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const [running, setRunning] = useState(false);
  const [loadout, setLoadout] = useState<Loadout>("smg");
  const [diff, setDiff] = useState<Difficulty>("operator");
  const [hud, setHud] = useState({ hp: 100, ammo: 30, intel: 0, kills: 0, alarm: false, msg: "BRIEFING: Recover 3 intel files 📁 then reach the helicopter 🚁." });

  useEffect(() => {
    const canvas = ref.current; if (!canvas || !running) return;
    const ctx = canvas.getContext("2d")!;
    const gun = LOADOUTS[loadout]; const cfg = DIFF[diff];
    const p = { x: 40, y: 460, a: 0, hp: cfg.hp as number, ammo: gun.mag as number, reloading: 0, last: 0 };
    const intel = [{ x: 260, y: 60, got: false }, { x: 470, y: 200, got: false }, { x: 740, y: 300, got: false }];
    const extract = { x: 720, y: 40, r: 34 };
    const spawns: [number, number][][] = [
      [[100, 80], [100, 300]], [[260, 200], [300, 320]], [[420, 60], [520, 60]], [[480, 260], [380, 290]], [[640, 120], [760, 120]],
      [[520, 420], [740, 420]], [[300, 460], [100, 460]], [[700, 200], [620, 300]], [[250, 120], [400, 60]],
    ];
    const guards: Guard[] = spawns.slice(0, cfg.guards).map((path) => ({ x: path[0]![0], y: path[0]![1], a: 0, hp: 100, path, wp: 1, alert: 0, cd: 60 }));
    const bullets: Bullet[] = []; const keys = new Set<string>(); let mouse = { x: 0, y: 0, down: false };
    let kills = 0, alarm = false, frame = 0, raf = 0, ended = false, detected = false;
    const t0 = performance.now();

    const kd = (e: KeyboardEvent) => { keys.add(e.key.toLowerCase()); if (e.key.toLowerCase() === "r" && p.ammo < gun.mag && !p.reloading) { p.reloading = 70; sfx.reload(); } if (["w", "a", "s", "d", " "].includes(e.key.toLowerCase())) e.preventDefault(); };
    const ku = (e: KeyboardEvent) => keys.delete(e.key.toLowerCase());
    const pos = (e: PointerEvent) => { const r = canvas.getBoundingClientRect(); mouse.x = ((e.clientX - r.left) / r.width) * W; mouse.y = ((e.clientY - r.top) / r.height) * H; };
    const pd = (e: PointerEvent) => { pos(e); mouse.down = true; };
    const pu = () => { mouse.down = false; };
    window.addEventListener("keydown", kd); window.addEventListener("keyup", ku);
    canvas.addEventListener("pointermove", pos); canvas.addEventListener("pointerdown", pd); window.addEventListener("pointerup", pu);

    const raise = () => { if (!alarm) { alarm = true; detected = true; sfx.alarm(); } guards.forEach((g) => { if (g.hp > 0) g.alert = 400; }); };
    const finish = (win: boolean) => {
      if (ended) return; ended = true;
      const got = intel.filter((i) => i.got).length; const secs = (performance.now() - t0) / 1000;
      const score = win ? got * 200 + kills * 50 + Math.max(0, Math.round(300 - secs * 2)) + (detected ? 0 : 500) + (diff === "elite" ? 300 : diff === "operator" ? 150 : 0) : got * 80 + kills * 30;
      win ? sfx.extract() : sfx.hit();
      setHud((h) => ({ ...h, msg: win ? `✅ EXTRACTED! ${detected ? "" : "GHOST BONUS +500 · "}SCORE ${score}` : `☠️ OPERATOR DOWN · SCORE ${score}` }));
      setRunning(false); onFinish(score);
    };

    const loop = () => {
      frame++;
      // movement
      const sneak = keys.has("shift"); const sp = sneak ? 1.4 : 2.6;
      let dx = 0, dy = 0; if (keys.has("w") || keys.has("arrowup")) dy -= 1; if (keys.has("s") || keys.has("arrowdown")) dy += 1; if (keys.has("a") || keys.has("arrowleft")) dx -= 1; if (keys.has("d") || keys.has("arrowright")) dx += 1;
      const m = Math.hypot(dx, dy) || 1; const nx = p.x + (dx / m) * sp, ny = p.y + (dy / m) * sp;
      if (!hitWall(nx, p.y, 10)) p.x = nx; if (!hitWall(p.x, ny, 10)) p.y = ny;
      p.a = Math.atan2(mouse.y - p.y, mouse.x - p.x);
      if (p.reloading > 0 && --p.reloading === 0) p.ammo = gun.mag;
      // shooting
      const now = performance.now();
      if ((mouse.down || keys.has(" ")) && !p.reloading && now - p.last > gun.rate) {
        if (p.ammo <= 0) { p.reloading = 70; sfx.reload(); }
        else {
          p.last = now; p.ammo--; loadout === "smg" ? sfx.silenced() : sfx.shoot();
          const pellets = loadout === "shotgun" ? 6 : 1;
          for (let i = 0; i < pellets; i++) { const a = p.a + (Math.random() - 0.5) * gun.spread; bullets.push({ x: p.x, y: p.y, vx: Math.cos(a) * 11, vy: Math.sin(a) * 11, enemy: false, life: 60 }); }
          guards.forEach((g) => { if (g.hp > 0 && Math.hypot(g.x - p.x, g.y - p.y) < gun.noise) g.alert = Math.max(g.alert, 200); });
          if (gun.noise > 200) raise();
        }
      }
      // guards
      guards.forEach((g) => {
        if (g.hp <= 0) return;
        const dist = Math.hypot(p.x - g.x, p.y - g.y); const toP = Math.atan2(p.y - g.y, p.x - g.x);
        let diffA = Math.abs(((toP - g.a + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
        const sees = dist < (sneak ? 150 : 200) && diffA < 0.6 && sight(g.x, g.y, p.x, p.y);
        if (sees) { g.alert = 400; if (dist < 170) raise(); }
        if (g.alert > 0) {
          g.alert--; g.a = toP;
          if (dist > 70) { const vx = Math.cos(toP) * 1.5, vy = Math.sin(toP) * 1.5; if (!hitWall(g.x + vx, g.y, 10)) g.x += vx; if (!hitWall(g.x, g.y + vy, 10)) g.y += vy; }
          if (--g.cd <= 0 && sight(g.x, g.y, p.x, p.y) && dist < 320) { g.cd = 55; const a = toP + (Math.random() - 0.5) * cfg.acc * 4; bullets.push({ x: g.x, y: g.y, vx: Math.cos(a) * 7, vy: Math.sin(a) * 7, enemy: true, life: 70 }); sfx.shoot(); }
        } else {
          const [tx, ty] = g.path[g.wp]!; const a = Math.atan2(ty - g.y, tx - g.x); g.a += (((a - g.a + Math.PI * 3) % (Math.PI * 2)) - Math.PI) * 0.1;
          g.x += Math.cos(a) * 0.9; g.y += Math.sin(a) * 0.9; if (Math.hypot(tx - g.x, ty - g.y) < 4) g.wp = (g.wp + 1) % g.path.length;
        }
        diffA = 0;
      });
      // bullets
      for (let i = bullets.length - 1; i >= 0; i--) {
        const b = bullets[i]!; b.x += b.vx; b.y += b.vy; b.life--;
        let dead = b.life <= 0 || hitWall(b.x, b.y);
        if (!dead && b.enemy && Math.hypot(b.x - p.x, b.y - p.y) < 11) { p.hp -= 12; dead = true; sfx.hit(); }
        if (!dead && !b.enemy) for (const g of guards) if (g.hp > 0 && Math.hypot(b.x - g.x, b.y - g.y) < 12) { g.hp -= gun.dmg; g.alert = 400; dead = true; if (g.hp <= 0) { kills++; sfx.coin(); } break; }
        if (dead) bullets.splice(i, 1);
      }
      intel.forEach((it) => { if (!it.got && Math.hypot(it.x - p.x, it.y - p.y) < 18) { it.got = true; sfx.success(); } });
      const got = intel.filter((i) => i.got).length;
      if (got === 3 && Math.hypot(extract.x - p.x, extract.y - p.y) < extract.r) return finish(true);
      if (p.hp <= 0) return finish(false);

      // ---- draw
      ctx.fillStyle = "#070a12"; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(80,200,255,.05)"; for (let gx = 0; gx < W; gx += 40) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); } for (let gy = 0; gy < H; gy += 40) { ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke(); }
      ctx.fillStyle = "#1b2436"; WALLS.forEach((w) => ctx.fillRect(w.x, w.y, w.w, w.h)); ctx.strokeStyle = "rgba(80,200,255,.35)"; WALLS.forEach((w) => ctx.strokeRect(w.x, w.y, w.w, w.h));
      ctx.beginPath(); ctx.arc(extract.x, extract.y, extract.r, 0, 7); ctx.fillStyle = got === 3 ? "rgba(60,255,150,.25)" : "rgba(120,120,120,.12)"; ctx.fill();
      ctx.font = "24px serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("🚁", extract.x, extract.y);
      intel.forEach((it) => { if (!it.got) { ctx.fillText("📁", it.x, it.y + Math.sin(frame / 12) * 2); } });
      guards.forEach((g) => {
        if (g.hp <= 0) { ctx.globalAlpha = 0.4; ctx.fillText("💀", g.x, g.y); ctx.globalAlpha = 1; return; }
        ctx.beginPath(); ctx.moveTo(g.x, g.y); ctx.arc(g.x, g.y, 200, g.a - 0.6, g.a + 0.6); ctx.closePath();
        ctx.fillStyle = g.alert > 0 ? "rgba(255,40,60,.16)" : "rgba(255,210,60,.08)"; ctx.fill();
        ctx.fillStyle = g.alert > 0 ? "#ff3350" : "#e0a030"; ctx.beginPath(); ctx.arc(g.x, g.y, 10, 0, 7); ctx.fill();
        ctx.fillStyle = "#fff"; ctx.fillRect(g.x + Math.cos(g.a) * 8 - 2, g.y + Math.sin(g.a) * 8 - 2, 4, 4);
      });
      bullets.forEach((b) => { ctx.fillStyle = b.enemy ? "#ff4466" : "#7ff"; ctx.fillRect(b.x - 2, b.y - 2, 4, 4); });
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a); ctx.shadowColor = "#3ef"; ctx.shadowBlur = 16; ctx.fillStyle = "#3ef"; ctx.beginPath(); ctx.arc(0, 0, 10, 0, 7); ctx.fill(); ctx.fillStyle = "#cff"; ctx.fillRect(6, -2, 14, 4); ctx.restore();
      if (sneak) { ctx.strokeStyle = "rgba(120,255,255,.3)"; ctx.beginPath(); ctx.arc(p.x, p.y, 18, 0, 7); ctx.stroke(); }
      if (alarm && frame % 40 < 20) { ctx.fillStyle = "rgba(255,0,40,.07)"; ctx.fillRect(0, 0, W, H); }
      if (frame % 6 === 0) setHud((h) => ({ ...h, hp: Math.max(0, p.hp), ammo: p.reloading ? -1 : p.ammo, intel: got, kills, alarm, msg: got === 3 ? "ALL INTEL SECURED — RUN TO THE 🚁 EXTRACTION ZONE!" : alarm ? "🚨 ALARM RAISED — hostiles converging!" : "Stay out of the yellow vision cones. Hold SHIFT to sneak." }));
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); canvas.removeEventListener("pointermove", pos); canvas.removeEventListener("pointerdown", pd); window.removeEventListener("pointerup", pu); };
  }, [running, loadout, diff, onFinish]);

  return (
    <div className="game-stage swat">
      <div className="game-hud">
        <span>HP <b className={hud.hp < 35 ? "text-destructive" : ""}>{hud.hp}</b></span>
        <span>AMMO <b>{hud.ammo < 0 ? "RELOADING" : hud.ammo}</b></span>
        <span>INTEL <b>{hud.intel}/3</b></span><span>KILLS <b>{hud.kills}</b></span>
        <span>{hud.alarm ? <b className="text-destructive">🚨 ALARM</b> : <b>👁️ HIDDEN</b>}</span>
      </div>
      <p className="swat-msg">{hud.msg}</p>
      <canvas ref={ref} width={W} height={H} style={{ cursor: "crosshair", touchAction: "none" }} />
      {!running && (
        <div className="swat-setup">
          <div><b>LOADOUT</b>{(Object.keys(LOADOUTS) as Loadout[]).map((k) => <Button key={k} size="sm" variant={loadout === k ? "default" : "outline"} onClick={() => { sfx.reload(); setLoadout(k); }}>{LOADOUTS[k].name}</Button>)}</div>
          <div><b>DIFFICULTY</b>{(Object.keys(DIFF) as Difficulty[]).map((k) => <Button key={k} size="sm" variant={diff === k ? "default" : "outline"} onClick={() => { sfx.click(); setDiff(k); }}>{k.toUpperCase()}</Button>)}</div>
          <Button onClick={() => { sfx.whoosh(); setHud({ hp: DIFF[diff].hp, ammo: LOADOUTS[loadout].mag, intel: 0, kills: 0, alarm: false, msg: "INFILTRATION STARTED." }); setRunning(true); }}>🔫 DEPLOY TEAM</Button>
        </div>
      )}
      <p className="text-xs text-muted-foreground">WASD move · MOUSE aim · CLICK/SPACE fire · R reload · SHIFT sneak. Stay undetected for the +500 Ghost bonus.</p>
    </div>
  );
}
