import { Palette, X } from "lucide-react";
import { useEffect, useState } from "react";

import { supabase } from "@/integrations/supabase/client";
import { safeStorage } from "@/js/core/security";
import { sfx } from "@/js/core/sfx";
import { useAuth } from "@/lib/auth";

type Mode = "off" | "custom" | "rainbow" | "pulse" | "wave" | "fire" | "ice" | "diamond";
const MODES: Mode[] = ["off", "custom", "rainbow", "pulse", "wave", "fire", "ice", "diamond"];
const FIXED: Partial<Record<Mode, number>> = { fire: 35, ice: 230, diamond: 195 };
type RgbState = { mode: Mode; hue: number; speed: number; light: number; edges: boolean };
const DEFAULT: RgbState = { mode: "off", hue: 200, speed: 8, light: 0.82, edges: true };
const PRESETS = [
  { name: "CYAN", hue: 202 }, { name: "MAGENTA", hue: 330 }, { name: "CRIMSON", hue: 25 },
  { name: "GOLD", hue: 85 }, { name: "TOXIC", hue: 140 }, { name: "VIOLET", hue: 295 },
];

export function RgbPanel() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [state, setState] = useState<RgbState>(DEFAULT);

  useEffect(() => {
    try { setState({ ...DEFAULT, ...JSON.parse(safeStorage.get("rgb", "{}")) }); } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const m = state.mode;
    root.classList.toggle("rgb-rainbow", m === "rainbow" || m === "wave");
    root.classList.toggle("rgb-custom", ["custom", "pulse", "fire", "ice", "diamond"].includes(m));
    root.classList.toggle("rgb-pulse", m === "pulse" || m === "fire" || m === "diamond");
    root.classList.toggle("rgb-glow", m === "diamond" || m === "ice" || m === "wave");
    const fixed = FIXED[m];
    root.style.setProperty("--rgb-speed", `${state.speed}s`);
    root.style.setProperty("--rgb-l", String(state.light));
    root.style.setProperty("--rgb-custom-h", String(fixed ?? state.hue));
    safeStorage.set("rgb", JSON.stringify(state));
  }, [state]);

  function update(patch: Partial<RgbState>) {
    sfx.click();
    setState((s) => {
      const next = { ...s, ...patch };
      if (user && patch.mode) void supabase.from("profiles").update({ rgb_mode: next.mode }).eq("id", user.id);
      return next;
    });
  }

  return (
    <>
      {state.mode !== "off" && state.edges && <><div className="rgb-edge top" aria-hidden /><div className="rgb-edge bottom" aria-hidden /></>}
      <button className="rgb-fab" onClick={() => { sfx.whoosh(); setOpen((o) => !o); }} aria-label="RGB panel"><Palette size={18} /></button>
      {open && (
        <div className="rgb-panel" role="dialog" aria-label="RGB lighting">
          <div className="rgb-panel-head"><b>RGB LAB</b><button onClick={() => setOpen(false)} aria-label="Close"><X size={14} /></button></div>
          <div className="rgb-modes">
            {MODES.map((m) => (
              <button key={m} className={state.mode === m ? "active" : ""} onClick={() => update({ mode: m })}>{({ off: "⏻", custom: "🎨", rainbow: "🌈", pulse: "💓", wave: "🌊", fire: "🔥", ice: "❄️", diamond: "💎" })[m]} {m === "custom" ? "STATIC" : m.toUpperCase()}</button>
            ))}
          </div>
          <p className="rgb-label">PRESETS</p>
          <div className="rgb-presets">
            {PRESETS.map((p) => <button key={p.name} style={{ background: `oklch(.78 .17 ${p.hue})` }} title={p.name} aria-label={p.name} onClick={() => update({ mode: "custom", hue: p.hue })} />)}
          </div>
          <label className="rgb-label">COLOR · {state.hue}°<input type="range" min={0} max={360} value={state.hue} onChange={(e) => setState((s) => ({ ...s, mode: "custom", hue: +e.target.value }))} className="hue-slider" /></label>
          <label className="rgb-label">RAINBOW SPEED · {state.speed}s<input type="range" min={2} max={30} value={state.speed} onChange={(e) => setState((s) => ({ ...s, speed: +e.target.value }))} /></label>
          <label className="rgb-label">BRIGHTNESS · {Math.round(state.light * 100)}%<input type="range" min={55} max={95} value={state.light * 100} onChange={(e) => setState((s) => ({ ...s, light: +e.target.value / 100 }))} /></label>
          <label className="rgb-check"><input type="checkbox" checked={state.edges} onChange={(e) => update({ edges: e.target.checked })} /> RGB EDGE LINES</label>
        </div>
      )}
    </>
  );
}
