"""🧠 LYS BRAIN — offline dual-mode companion logic."""
import ast
import operator

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.Pow: operator.pow, ast.USub: operator.neg}

def _calculate(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_calculate(node.left), _calculate(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPS:
        return OPS[type(node.op)](_calculate(node.operand))
    raise ValueError("unsupported expression")

def respond(query: str, mode: str = "tierna") -> str:
    clean = query.strip()[:240]
    try:
        value = _calculate(ast.parse(clean, mode="eval").body)
        return f"Resultado táctico: {value}."
    except (SyntaxError, ValueError, TypeError, ZeroDivisionError, OverflowError):
        prefix = "Estoy contigo, Sung." if mode == "tierna" else "Reporte de capitana."
        return f"{prefix} LYS 22 recibió: {clean or 'sin señal'}."