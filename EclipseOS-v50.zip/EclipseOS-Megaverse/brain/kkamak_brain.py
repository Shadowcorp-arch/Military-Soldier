"""🐦‍⬛ KKAMAK MOTOR — offline scan responses."""

def scan(sector: str) -> dict:
    return {"agent": "KKAMAK", "height_cm": 30, "age_years": 500, "eye": "yellow", "sector": sector[:80], "threat": "clear", "motor": "shadow"}