from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from lys_brain import respond
from kkamak_brain import scan

app = FastAPI(title="ECLIPSEOS Offline Brain", version="9.1")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:8080", "http://127.0.0.1:8080"], allow_methods=["GET"], allow_headers=["*"])

@app.get("/health")
def health():
    return {"online": True, "system": "ECLIPSEOS", "version": "9.1"}

@app.get("/lys")
def lys(q: str = Query(max_length=240), mode: str = Query(default="tierna", pattern="^(tierna|capitana)$")):
    return {"answer": respond(q, mode), "mode": mode}

@app.get("/kkamak")
def kkamak(sector: str = Query(default="Seoul", max_length=80)):
    return scan(sector)